export type Category =
  | 'All'
  | 'Accommodation'
  | 'Restaurants'
  | 'Retail'
  | 'Services'
  | 'Health & Beauty'
  | 'Events'
  | 'Education';

export type Province =
  | 'All Locations'
  | 'Gauteng'
  | 'Western Cape'
  | 'KwaZulu-Natal'
  | 'Eastern Cape'
  | 'Limpopo'
  | 'Mpumalanga'
  | 'North West'
  | 'Free State'
  | 'Northern Cape';

export interface Business {
  id: number;
  name: string;
  tagline: string;
  category: Category;
  city: string;
  province: Province;
  rating: number;
  reviewCount: number;
  verified: boolean;
  featured: boolean;
  coverImage: string;
  logoImage: string;
  whatsapp: string;
  profileUrl: string;
  tags: string[];
  description: string;
}

export const businesses: Business[] = [
  {
    id: 1,
    name: 'The Vineyard Hotel',
    tagline: 'Luxury Boutique Hotel in Cape Town',
    category: 'Accommodation',
    city: 'Cape Town',
    province: 'Western Cape',
    rating: 4.8,
    reviewCount: 1240,
    verified: true,
    featured: true,
    coverImage: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27214001234',
    profileUrl: '#',
    tags: ['Hotel', 'Spa', 'Fine Dining', 'Conference'],
    description: 'Award-winning luxury hotel nestled against the slopes of Table Mountain with world-class spa facilities.',
  },
  {
    id: 2,
    name: 'Mzoli\'s Place',
    tagline: 'Iconic Braai & Shisa Nyama Experience',
    category: 'Restaurants',
    city: 'Gugulethu',
    province: 'Western Cape',
    rating: 4.6,
    reviewCount: 892,
    verified: true,
    featured: true,
    coverImage: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/3338497/pexels-photo-3338497.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27216371040',
    profileUrl: '#',
    tags: ['Braai', 'Shisa Nyama', 'Township Tour', 'Weekend'],
    description: 'World-famous township restaurant serving traditional South African braai since 2003.',
  },
  {
    id: 3,
    name: 'Sandton Smile Dental Studio',
    tagline: 'Premium Cosmetic & Family Dentistry',
    category: 'Health & Beauty',
    city: 'Sandton',
    province: 'Gauteng',
    rating: 4.9,
    reviewCount: 317,
    verified: true,
    featured: true,
    coverImage: 'https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/305565/pexels-photo-305565.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27118832100',
    profileUrl: '#',
    tags: ['Dental', 'Cosmetic', 'Implants', 'Whitening'],
    description: 'State-of-the-art dental clinic offering full cosmetic and restorative services in the heart of Sandton.',
  },
  {
    id: 4,
    name: 'Durban Spice Market',
    tagline: 'Authentic Spices & Curry Blends Since 1987',
    category: 'Retail',
    city: 'Durban',
    province: 'KwaZulu-Natal',
    rating: 4.7,
    reviewCount: 543,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/1340116/pexels-photo-1340116.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/2802527/pexels-photo-2802527.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27313061234',
    profileUrl: '#',
    tags: ['Spices', 'Curry', 'Indian', 'Wholesale'],
    description: 'Family-run spice emporium supplying restaurants and homes across KZN with the finest curry blends.',
  },
  {
    id: 5,
    name: 'Cape Digital Creative Co.',
    tagline: 'Brand Design, Web & Social Media',
    category: 'Services',
    city: 'Cape Town',
    province: 'Western Cape',
    rating: 4.8,
    reviewCount: 209,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/3861958/pexels-photo-3861958.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27216701234',
    profileUrl: '#',
    tags: ['Branding', 'Web Design', 'Social Media', 'SEO'],
    description: 'Full-service digital agency crafting bold identities for Cape Town startups and established brands.',
  },
  {
    id: 6,
    name: 'Joburg Event Collective',
    tagline: 'Corporate & Private Event Specialists',
    category: 'Events',
    city: 'Johannesburg',
    province: 'Gauteng',
    rating: 4.5,
    reviewCount: 188,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/2747449/pexels-photo-2747449.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27117831234',
    profileUrl: '#',
    tags: ['Corporate Events', 'Décor', 'Catering', 'AV'],
    description: 'End-to-end event management delivering unforgettable experiences for Johannesburg\'s top corporates.',
  },
  {
    id: 7,
    name: 'Kruger Safari Lodge',
    tagline: 'Exclusive Big 5 Safari Experiences',
    category: 'Accommodation',
    city: 'Hoedspruit',
    province: 'Limpopo',
    rating: 4.9,
    reviewCount: 672,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/631317/pexels-photo-631317.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/2335126/pexels-photo-2335126.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27152930101',
    profileUrl: '#',
    tags: ['Safari', 'Big 5', 'Luxury Lodge', 'Conservation'],
    description: 'Award-winning private game lodge on the edge of the Greater Kruger offering twice-daily game drives.',
  },
  {
    id: 8,
    name: 'Pretoria Academy of Music',
    tagline: 'Classical & Contemporary Music Tuition',
    category: 'Education',
    city: 'Pretoria',
    province: 'Gauteng',
    rating: 4.6,
    reviewCount: 134,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/164821/pexels-photo-164821.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/6157049/pexels-photo-6157049.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27123451234',
    profileUrl: '#',
    tags: ['Piano', 'Guitar', 'Vocals', 'Theory'],
    description: 'ABRSM-affiliated music school offering graded exams and performance opportunities for all ages.',
  },
  {
    id: 9,
    name: 'Glow Beauty Bar',
    tagline: 'Natural Skincare & Luxury Treatments',
    category: 'Health & Beauty',
    city: 'Umhlanga',
    province: 'KwaZulu-Natal',
    rating: 4.7,
    reviewCount: 256,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27313031234',
    profileUrl: '#',
    tags: ['Skincare', 'Facials', 'Massages', 'Nails'],
    description: 'Boutique beauty studio specialising in organic treatments and personalized skin consultations.',
  },
  {
    id: 10,
    name: 'Stellenbosch Wine Estate',
    tagline: 'Cellar Door Tastings & Farm-to-Table',
    category: 'Restaurants',
    city: 'Stellenbosch',
    province: 'Western Cape',
    rating: 4.8,
    reviewCount: 987,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/434311/pexels-photo-434311.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/1407846/pexels-photo-1407846.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27218801234',
    profileUrl: '#',
    tags: ['Wine Tasting', 'Restaurant', 'Weddings', 'Tours'],
    description: 'Celebrated wine estate producing award-winning reds and whites with panoramic vineyard restaurant views.',
  },
  {
    id: 11,
    name: 'Soweto Threads Boutique',
    tagline: 'Contemporary African Fashion & Lifestyle',
    category: 'Retail',
    city: 'Soweto',
    province: 'Gauteng',
    rating: 4.5,
    reviewCount: 198,
    verified: true,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/2220316/pexels-photo-2220316.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27118381234',
    profileUrl: '#',
    tags: ['Fashion', 'African Print', 'Lifestyle', 'Custom'],
    description: 'Curated African fashion label blending traditional Kente prints with contemporary streetwear silhouettes.',
  },
  {
    id: 12,
    name: 'Port Elizabeth Logistics Pro',
    tagline: 'Same-Day Freight & Last-Mile Delivery',
    category: 'Services',
    city: 'Gqeberha',
    province: 'Eastern Cape',
    rating: 4.4,
    reviewCount: 121,
    verified: false,
    featured: false,
    coverImage: 'https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg?auto=compress&cs=tinysrgb&w=800',
    logoImage: 'https://images.pexels.com/photos/4246174/pexels-photo-4246174.jpeg?auto=compress&cs=tinysrgb&w=100',
    whatsapp: '+27415041234',
    profileUrl: '#',
    tags: ['Freight', 'Delivery', 'Courier', 'Warehousing'],
    description: 'Fast, reliable logistics network covering Eastern Cape with real-time parcel tracking for businesses.',
  },
];

export const categories: Category[] = [
  'All', 'Accommodation', 'Restaurants', 'Retail', 'Services', 'Health & Beauty', 'Events', 'Education',
];

export const provinces: Province[] = [
  'All Locations', 'Gauteng', 'Western Cape', 'KwaZulu-Natal', 'Eastern Cape', 'Limpopo', 'Mpumalanga', 'North West', 'Free State', 'Northern Cape',
];
