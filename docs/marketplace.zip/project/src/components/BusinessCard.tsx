import { MapPin, ExternalLink, MessageCircle, BadgeCheck } from 'lucide-react';
import StarRating, { VerifiedBadge } from '@/components/StarRating';
import type { Business } from '@/data/businesses';

interface BusinessCardProps {
  business: Business;
}

export default function BusinessCard({ business: biz }: BusinessCardProps) {
  return (
    <article className="group bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-blue-200 hover:shadow-lg hover:shadow-blue-50 transition-all duration-250 flex flex-col">
      {/* Cover image */}
      <div className="relative h-40 overflow-hidden shrink-0">
        <img
          src={biz.coverImage}
          alt={biz.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

        {/* Category badge */}
        <span className="absolute top-2.5 right-2.5 bg-black/45 backdrop-blur-sm text-white text-[11px] font-semibold px-2 py-0.5 rounded-full border border-white/20">
          {biz.category}
        </span>

        {/* Logo overlapping banner */}
        <div className="absolute -bottom-5 left-3.5">
          <div className="w-11 h-11 rounded-xl border-2 border-white shadow-md overflow-hidden bg-gray-100">
            <img src={biz.logoImage} alt="" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      {/* Card body */}
      <div className="pt-7 px-3.5 pb-3.5 flex flex-col flex-1">
        {/* Name row */}
        <div className="flex items-start justify-between gap-1.5 mb-0.5">
          <h3 className="font-bold text-gray-900 text-sm leading-tight group-hover:text-blue-700 transition-colors flex-1">
            {biz.name}
          </h3>
          {biz.verified && (
            <BadgeCheck size={15} className="text-blue-500 fill-blue-100 shrink-0 mt-0.5" />
          )}
        </div>

        <p className="text-gray-500 text-xs mb-2 leading-relaxed line-clamp-2 flex-1">{biz.tagline}</p>

        {/* Rating */}
        <StarRating rating={biz.rating} reviewCount={biz.reviewCount} size="sm" />

        {/* Location */}
        <div className="flex items-center gap-1 text-gray-400 text-xs mt-1.5 mb-2">
          <MapPin size={11} />
          <span>{biz.city}, {biz.province}</span>
        </div>

        {/* Verified badge */}
        {biz.verified && <VerifiedBadge className="mb-2.5 self-start" />}

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {biz.tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="bg-gray-100 text-gray-600 rounded-md px-2 py-0.5 text-[11px] font-medium"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* CTAs */}
        <div className="flex gap-2 mt-auto">
          <a
            href={biz.profileUrl}
            className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 rounded-lg transition-colors shadow-sm"
          >
            <ExternalLink size={12} />
            Visit Profile
          </a>
          <a
            href={`https://wa.me/${biz.whatsapp.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 hover:border-emerald-300 text-xs font-semibold py-2 rounded-lg transition-colors"
          >
            <MessageCircle size={12} />
            WhatsApp
          </a>
        </div>
      </div>
    </article>
  );
}
