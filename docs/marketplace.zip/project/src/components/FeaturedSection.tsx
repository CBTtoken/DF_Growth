import { MapPin, ExternalLink, MessageCircle, BadgeCheck } from 'lucide-react';
import StarRating, { VerifiedBadge } from '@/components/StarRating';
import type { Business } from '@/data/businesses';

interface FeaturedSectionProps {
  businesses: Business[];
}

export default function FeaturedSection({ businesses }: FeaturedSectionProps) {
  if (businesses.length === 0) return null;

  return (
    <section className="bg-gradient-to-b from-slate-950 to-slate-900 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-5 bg-blue-500 rounded-full block"></span>
              <h2 className="text-base font-bold text-white tracking-tight">Featured Premium Members</h2>
            </div>
            <span className="hidden sm:inline-flex items-center gap-1 bg-amber-400/10 text-amber-400 border border-amber-400/20 rounded-full px-2.5 py-0.5 text-xs font-semibold">
              <BadgeCheck size={11} />
              Top Rated
            </span>
          </div>
          <a href="#" className="text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors">
            View all →
          </a>
        </div>

        {/* 3-col grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {businesses.slice(0, 3).map((biz) => (
            <FeaturedCard key={biz.id} business={biz} />
          ))}
        </div>
      </div>
    </section>
  );
}

function FeaturedCard({ business: biz }: { business: Business }) {
  return (
    <article className="group bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:bg-white/8 hover:border-white/20 hover:shadow-2xl hover:shadow-black/30 transition-all duration-300 cursor-pointer">
      {/* Cover image */}
      <div className="relative h-36 overflow-hidden">
        <img
          src={biz.coverImage}
          alt={biz.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />

        {/* Category tag top-right */}
        <span className="absolute top-2.5 right-2.5 bg-black/50 backdrop-blur-sm text-white text-xs font-semibold px-2 py-0.5 rounded-full border border-white/20">
          {biz.category}
        </span>

        {/* Logo avatar overlapping banner */}
        <div className="absolute -bottom-5 left-4">
          <div className="w-12 h-12 rounded-xl border-2 border-white shadow-lg overflow-hidden bg-gray-100">
            <img src={biz.logoImage} alt={`${biz.name} logo`} className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      {/* Card body */}
      <div className="pt-7 px-4 pb-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-bold text-white text-sm leading-tight group-hover:text-blue-300 transition-colors">
            {biz.name}
          </h3>
          {biz.verified && (
            <BadgeCheck size={16} className="text-blue-400 fill-blue-400/20 shrink-0 mt-0.5" />
          )}
        </div>

        <p className="text-gray-400 text-xs mb-2.5 leading-relaxed line-clamp-2">{biz.description}</p>

        {/* Rating */}
        <div className="mb-2.5">
          <StarRating rating={biz.rating} reviewCount={biz.reviewCount} size="sm" />
        </div>

        {/* Location */}
        <div className="flex items-center gap-1 text-gray-500 text-xs mb-3">
          <MapPin size={11} />
          <span>{biz.city}, {biz.province}</span>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3.5">
          {biz.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="bg-white/8 text-gray-300 border border-white/10 rounded-md px-2 py-0.5 text-xs font-medium">
              {tag}
            </span>
          ))}
        </div>

        {/* CTAs */}
        <div className="flex gap-2">
          <a
            href={biz.profileUrl}
            className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold py-2 rounded-lg transition-colors"
          >
            <ExternalLink size={12} />
            Visit Profile
          </a>
          <a
            href={`https://wa.me/${biz.whatsapp.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold py-2 rounded-lg transition-colors"
          >
            <MessageCircle size={12} />
            WhatsApp
          </a>
        </div>
      </div>
    </article>
  );
}
