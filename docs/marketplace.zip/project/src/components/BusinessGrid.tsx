import { Search } from 'lucide-react';
import BusinessCard from '@/components/BusinessCard';
import type { Business } from '@/data/businesses';

interface BusinessGridProps {
  businesses: Business[];
  keyword: string;
  selectedCategory: string;
  selectedProvince: string;
}

export default function BusinessGrid({ businesses, keyword, selectedCategory, selectedProvince }: BusinessGridProps) {
  if (businesses.length === 0) {
    return (
      <section className="bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-14 h-14 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Search size={24} className="text-gray-400" />
          </div>
          <h3 className="text-base font-semibold text-gray-900 mb-1">No results found</h3>
          <p className="text-sm text-gray-500 max-w-xs mx-auto">
            Try adjusting your filters or search term to find businesses in your area.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section heading */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <span className="w-1.5 h-5 bg-blue-500 rounded-full block"></span>
            <h2 className="text-base font-bold text-gray-900 tracking-tight">
              {selectedCategory === 'All' ? 'All Businesses' : selectedCategory}
              {selectedProvince !== 'All Locations' && (
                <span className="font-normal text-gray-500"> in {selectedProvince}</span>
              )}
              {keyword && (
                <span className="font-normal text-gray-500"> matching "{keyword}"</span>
              )}
            </h2>
          </div>
          <span className="text-xs text-gray-400 font-medium">
            {businesses.length} result{businesses.length !== 1 ? 's' : ''}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {businesses.map((biz) => (
            <BusinessCard key={biz.id} business={biz} />
          ))}
        </div>
      </div>
    </section>
  );
}
