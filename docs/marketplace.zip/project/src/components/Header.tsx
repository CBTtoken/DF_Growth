import { useState, useEffect } from 'react';
import { Menu, X, Zap, ChevronDown } from 'lucide-react';

interface HeaderProps {
  scrolled: boolean;
}

export default function Header({ scrolled }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white border-b border-gray-200 shadow-sm'
          : 'bg-white border-b border-gray-100'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 shrink-0">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm">
              <Zap size={15} className="text-white fill-white" />
            </div>
            <span className="font-bold text-gray-900 text-base tracking-tight leading-none">
              DigitalFlyer<span className="text-blue-600"> Growth</span>
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
            <a href="#" className="hover:text-gray-900 transition-colors">Directory</a>
            <a href="#" className="hover:text-gray-900 transition-colors flex items-center gap-1">
              Categories <ChevronDown size={13} />
            </a>
            <a href="#" className="hover:text-gray-900 transition-colors">Advertise</a>
            <a href="#" className="hover:text-gray-900 transition-colors">Blog</a>
          </nav>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center gap-2">
            <a
              href="#"
              className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors px-3 py-1.5"
            >
              Sign In
            </a>
            <a
              href="#"
              className="text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-1.5 transition-colors shadow-sm"
            >
              List Your Business
            </a>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 transition-colors"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 py-3 space-y-2">
          {['Directory', 'Categories', 'Advertise', 'Blog'].map((item) => (
            <a key={item} href="#" className="block text-sm font-medium text-gray-700 py-2 hover:text-blue-600 transition-colors">
              {item}
            </a>
          ))}
          <div className="pt-2 border-t border-gray-100 flex flex-col gap-2">
            <a href="#" className="text-sm font-medium text-gray-700 py-2">Sign In</a>
            <a href="#" className="text-sm font-semibold bg-blue-600 text-white rounded-lg px-4 py-2 text-center transition-colors">
              List Your Business
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
