import { useRef, useState } from 'react';
import { Search, MapPin, Grid3X3, ChevronDown, X, SlidersHorizontal } from 'lucide-react';
import { categories, provinces, type Category, type Province } from '@/data/businesses';

interface FilterBarProps {
  selectedCategory: Category;
  selectedProvince: Province;
  keyword: string;
  onCategoryChange: (c: Category) => void;
  onProvinceChange: (p: Province) => void;
  onKeywordChange: (k: string) => void;
  totalCount: number;
}

export default function FilterBar({
  selectedCategory,
  selectedProvince,
  keyword,
  onCategoryChange,
  onProvinceChange,
  onKeywordChange,
  totalCount,
}: FilterBarProps) {
  const [catOpen, setCatOpen] = useState(false);
  const [provOpen, setProvOpen] = useState(false);
  const keywordRef = useRef<HTMLInputElement>(null);

  return (
    <div className="bg-white border-b border-gray-200 sticky top-14 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Keyword search */}
          <div className="relative flex-1 min-w-0">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              ref={keywordRef}
              type="text"
              value={keyword}
              onChange={(e) => onKeywordChange(e.target.value)}
              placeholder="Search businesses, services, products…"
              className="w-full pl-9 pr-8 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all placeholder:text-gray-400"
            />
            {keyword && (
              <button
                onClick={() => onKeywordChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={14} />
              </button>
            )}
          </div>

          <div className="flex gap-2">
            {/* Category dropdown */}
            <div className="relative">
              <button
                onClick={() => { setCatOpen(!catOpen); setProvOpen(false); }}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 hover:border-gray-300 transition-all whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <Grid3X3 size={14} className="text-gray-500" />
                <span className="text-gray-700">{selectedCategory}</span>
                <ChevronDown size={13} className={`text-gray-400 transition-transform ${catOpen ? 'rotate-180' : ''}`} />
              </button>
              {catOpen && (
                <div className="absolute top-full left-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-50 min-w-[180px]">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => { onCategoryChange(cat); setCatOpen(false); }}
                      className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                        selectedCategory === cat
                          ? 'bg-blue-50 text-blue-700 font-semibold'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Province dropdown */}
            <div className="relative">
              <button
                onClick={() => { setProvOpen(!provOpen); setCatOpen(false); }}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 hover:border-gray-300 transition-all whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <MapPin size={14} className="text-gray-500" />
                <span className="text-gray-700 max-w-[100px] truncate">{selectedProvince}</span>
                <ChevronDown size={13} className={`text-gray-400 transition-transform ${provOpen ? 'rotate-180' : ''}`} />
              </button>
              {provOpen && (
                <div className="absolute top-full right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-50 min-w-[180px]">
                  {provinces.map((prov) => (
                    <button
                      key={prov}
                      onClick={() => { onProvinceChange(prov); setProvOpen(false); }}
                      className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                        selectedProvince === prov
                          ? 'bg-blue-50 text-blue-700 font-semibold'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      {prov}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Category pill bar */}
        <div className="flex items-center gap-2 mt-2.5 overflow-x-auto pb-0.5 scrollbar-hide">
          <SlidersHorizontal size={13} className="text-gray-400 shrink-0" />
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => onCategoryChange(cat)}
              className={`shrink-0 px-3 py-1 rounded-full text-xs font-semibold border transition-all ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300 hover:text-blue-600'
              }`}
            >
              {cat}
            </button>
          ))}
          <span className="ml-auto shrink-0 text-xs text-gray-400 font-medium">
            {totalCount} listing{totalCount !== 1 ? 's' : ''}
          </span>
        </div>
      </div>
    </div>
  );
}
