import { TrendingUp, Star, Shield, Users } from 'lucide-react';

export default function Hero() {
  const stats = [
    { icon: Users, value: '12,400+', label: 'Listed Businesses' },
    { icon: Star, value: '4.8 avg', label: 'Google Rating' },
    { icon: Shield, value: '8,200+', label: 'Verified Members' },
    { icon: TrendingUp, value: '9 Provinces', label: 'SA Coverage' },
  ];

  return (
    <section className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-3 py-1 mb-4">
            <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse"></span>
            <span className="text-blue-300 text-xs font-semibold">South Africa's #1 Business Directory</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight tracking-tight mb-3">
            Find & Connect with
            <br />
            <span className="text-blue-400">Trusted Local Businesses</span>
          </h1>

          <p className="text-gray-400 text-sm sm:text-base leading-relaxed mb-6 max-w-lg">
            Discover verified restaurants, hotels, services, and retailers across all 9 provinces —
            with real Google ratings and direct WhatsApp contact.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {stats.map(({ icon: Icon, value, label }) => (
              <div
                key={label}
                className="bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 flex items-center gap-2.5"
              >
                <div className="w-7 h-7 bg-blue-600/20 rounded-lg flex items-center justify-center shrink-0">
                  <Icon size={14} className="text-blue-400" />
                </div>
                <div>
                  <div className="text-white font-bold text-sm leading-none">{value}</div>
                  <div className="text-gray-500 text-[11px] leading-tight mt-0.5">{label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
