import { Zap, MapPin, Phone, Mail, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm">
                <Zap size={14} className="text-white fill-white" />
              </div>
              <span className="font-bold text-white text-sm">
                DigitalFlyer<span className="text-blue-400"> Growth</span>
              </span>
            </div>
            <p className="text-gray-500 text-xs leading-relaxed mb-4">
              South Africa's premium business directory connecting local brands with their ideal customers.
            </p>
            <div className="flex items-center gap-3">
              {[Facebook, Instagram, Twitter, Linkedin].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-7 h-7 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center text-gray-500 hover:text-white hover:bg-white/10 hover:border-white/20 transition-all"
                >
                  <Icon size={13} />
                </a>
              ))}
            </div>
          </div>

          {/* Directory */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-3">Directory</h4>
            <ul className="space-y-2">
              {['Browse Categories', 'Featured Listings', 'New Businesses', 'Top Rated', 'Recently Added'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-500 text-xs hover:text-gray-300 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* For Business */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-3">For Businesses</h4>
            <ul className="space-y-2">
              {['List Your Business', 'Premium Plans', 'Advertising', 'Member Dashboard', 'Success Stories'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-500 text-xs hover:text-gray-300 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-3">Contact</h4>
            <ul className="space-y-2.5">
              <li className="flex items-center gap-2 text-gray-500 text-xs">
                <MapPin size={12} className="text-gray-600 shrink-0" />
                <span>Cape Town, South Africa</span>
              </li>
              <li className="flex items-center gap-2 text-gray-500 text-xs">
                <Phone size={12} className="text-gray-600 shrink-0" />
                <a href="tel:+27214001234" className="hover:text-gray-300 transition-colors">+27 21 400 1234</a>
              </li>
              <li className="flex items-center gap-2 text-gray-500 text-xs">
                <Mail size={12} className="text-gray-600 shrink-0" />
                <a href="mailto:hello@digitalflyersa.co.za" className="hover:text-gray-300 transition-colors">hello@digitalflyersa.co.za</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-6 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-gray-600 text-xs">
            © {new Date().getFullYear()} DigitalFlyer Growth. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            {['Privacy Policy', 'Terms of Use', 'Cookie Policy'].map((item) => (
              <a key={item} href="#" className="text-gray-600 text-xs hover:text-gray-400 transition-colors">
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
