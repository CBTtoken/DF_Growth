import { Star, CheckCircle2 } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  reviewCount: number;
  size?: 'sm' | 'md';
}

export default function StarRating({ rating, reviewCount, size = 'sm' }: StarRatingProps) {
  const full = Math.floor(rating);
  const partial = rating - full;
  const empty = 5 - Math.ceil(rating);
  const starSize = size === 'sm' ? 12 : 14;

  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-0.5">
        {Array.from({ length: full }).map((_, i) => (
          <Star key={`f${i}`} size={starSize} className="fill-amber-400 text-amber-400" />
        ))}
        {partial > 0 && (
          <span className="relative inline-block" style={{ width: starSize, height: starSize }}>
            <Star size={starSize} className="text-gray-200 fill-gray-200 absolute inset-0" />
            <span
              className="overflow-hidden absolute inset-0 flex"
              style={{ width: `${partial * 100}%` }}
            >
              <Star size={starSize} className="fill-amber-400 text-amber-400 shrink-0" />
            </span>
          </span>
        )}
        {Array.from({ length: empty }).map((_, i) => (
          <Star key={`e${i}`} size={starSize} className="fill-gray-200 text-gray-200" />
        ))}
      </div>
      <span className={`font-semibold text-gray-800 ${size === 'sm' ? 'text-xs' : 'text-sm'}`}>
        {rating.toFixed(1)}
      </span>
      <span className={`text-gray-400 ${size === 'sm' ? 'text-xs' : 'text-sm'}`}>
        ({reviewCount.toLocaleString()})
      </span>
    </div>
  );
}

interface VerifiedBadgeProps {
  className?: string;
}

export function VerifiedBadge({ className = '' }: VerifiedBadgeProps) {
  return (
    <span className={`inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full px-2 py-0.5 text-xs font-semibold ${className}`}>
      <CheckCircle2 size={11} className="fill-emerald-500 text-white" />
      Verified Member
    </span>
  );
}
