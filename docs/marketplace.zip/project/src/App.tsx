import { useState, useEffect, useMemo } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import FilterBar from '@/components/FilterBar';
import FeaturedSection from '@/components/FeaturedSection';
import BusinessGrid from '@/components/BusinessGrid';
import Footer from '@/components/Footer';
import { businesses, type Category, type Province } from '@/data/businesses';

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');
  const [selectedProvince, setSelectedProvince] = useState<Province>('All Locations');
  const [keyword, setKeyword] = useState('');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const filtered = useMemo(() => {
    const kw = keyword.toLowerCase().trim();
    return businesses.filter((b) => {
      const matchCat = selectedCategory === 'All' || b.category === selectedCategory;
      const matchProv = selectedProvince === 'All Locations' || b.province === selectedProvince;
      const matchKw =
        !kw ||
        b.name.toLowerCase().includes(kw) ||
        b.tagline.toLowerCase().includes(kw) ||
        b.description.toLowerCase().includes(kw) ||
        b.tags.some((t) => t.toLowerCase().includes(kw)) ||
        b.city.toLowerCase().includes(kw);
      return matchCat && matchProv && matchKw;
    });
  }, [selectedCategory, selectedProvince, keyword]);

  const featured = useMemo(
    () => businesses.filter((b) => b.featured && b.verified),
    []
  );

  // Non-featured listings in grid
  const gridBusinesses = useMemo(
    () => filtered.filter((b) => !b.featured),
    [filtered]
  );

  // Show featured only when no active filter
  const showFeatured =
    selectedCategory === 'All' &&
    selectedProvince === 'All Locations' &&
    keyword === '';

  return (
    <div className="bg-white">
      <Header scrolled={scrolled} />

      {/* Push content below fixed header */}
      <div className="pt-14">
        <Hero />
        <FilterBar
          selectedCategory={selectedCategory}
          selectedProvince={selectedProvince}
          keyword={keyword}
          onCategoryChange={setSelectedCategory}
          onProvinceChange={setSelectedProvince}
          onKeywordChange={setKeyword}
          totalCount={showFeatured ? businesses.length : filtered.length}
        />
        {showFeatured && <FeaturedSection businesses={featured} />}
        <BusinessGrid
          businesses={showFeatured ? gridBusinesses : filtered}
          keyword={keyword}
          selectedCategory={selectedCategory}
          selectedProvince={selectedProvince}
        />
        <Footer />
      </div>
    </div>
  );
}
