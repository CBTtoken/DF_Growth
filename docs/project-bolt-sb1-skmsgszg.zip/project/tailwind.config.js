/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        sand: {
          50: '#fbf8f3',
          100: '#f5efe4',
          200: '#ece0c9',
          300: '#dec9a1',
          400: '#ccab73',
          500: '#bd8f4f',
          600: '#a8753f',
          700: '#8a5b36',
          800: '#704930',
          900: '#5d3d2a',
        },
        forest: {
          50: '#f1f7f2',
          100: '#ddeee0',
          200: '#bddcc3',
          300: '#8fc29a',
          400: '#5fa173',
          500: '#3f8456',
          600: '#2f6a44',
          700: '#275538',
          800: '#21442e',
          900: '#1c3926',
          950: '#0e2014',
        },
        ink: '#1a1714',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        display: ['Fraunces', 'Georgia', 'serif'],
      },
      boxShadow: {
        soft: '0 1px 2px rgba(26,23,20,0.04), 0 8px 24px rgba(26,23,20,0.06)',
        lift: '0 2px 4px rgba(26,23,20,0.06), 0 18px 40px rgba(26,23,20,0.12)',
      },
    },
  },
  plugins: [],
};
