import { useEffect, useRef, useState } from "react";
import {
  MessageCircle,
  ArrowRight,
  BadgeCheck,
  MapPin,
  Sparkles,
  Send,
  FileText,
  Share2,
  Star,
  CheckCircle2,
  X,
  Tag,
  HelpCircle,
  PenLine,
  Rocket,
  UserCircle,
} from "lucide-react";
import { agent } from "@/agent.config";

/* ----------------------------- helpers ----------------------------- */

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(".reveal");
    if (!("IntersectionObserver" in window) || els.length === 0) {
      els.forEach((el) => el.classList.add("is-visible"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            (e.target as HTMLElement).classList.add("is-visible");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -30px 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function useStickyCta() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 520);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return show;
}

/* ----------------------------- atoms ----------------------------- */

function WhatsAppButton({
  label = `WhatsApp ${agent.firstName}`,
  className = "",
}: {
  label?: string;
  className?: string;
}) {
  return (
    <a
      href={agent.whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={`group inline-flex items-center justify-center gap-2 rounded-full bg-forest-600 px-6 py-3 text-base font-semibold text-white shadow-soft transition hover:bg-forest-700 hover:shadow-lift active:scale-[0.98] ${className}`}
    >
      <MessageCircle className="h-5 w-5" />
      <span>{label}</span>
      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
    </a>
  );
}

function PricesButton({ className = "" }: { className?: string }) {
  return (
    <a
      href={agent.pricesUrl}
      className={`inline-flex items-center justify-center gap-2 rounded-full border border-forest-700/30 bg-white/70 px-6 py-3 text-base font-semibold text-forest-800 backdrop-blur transition hover:border-forest-700/50 hover:bg-white active:scale-[0.98] ${className}`}
    >
      <Tag className="h-5 w-5" />
      <span>See prices</span>
    </a>
  );
}

function SectionLabel({
  children,
  tone = "dark",
}: {
  children: React.ReactNode;
  tone?: "dark" | "light";
}) {
  return (
    <span
      className={`inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] ${
        tone === "light" ? "text-forest-300" : "text-forest-700"
      }`}
    >
      <span
        className={`h-px w-6 ${tone === "light" ? "bg-forest-400" : "bg-forest-400"}`}
      />
      {children}
    </span>
  );
}

/* ----------------------------- hero ----------------------------- */

function Hero() {
  const hasPhoto = agent.photoUrl && agent.photoUrl.length > 0;
  return (
    <header className="relative overflow-hidden bg-sand-50">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-forest-200/40 blur-3xl" />
        <div className="absolute -bottom-32 -left-20 h-80 w-80 rounded-full bg-sand-300/50 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-6xl px-6 pt-12 pb-14 sm:pt-16 sm:pb-16">
        <div className="grid items-center gap-10 sm:gap-14 lg:grid-cols-[1.1fr_0.9fr]">
          {/* copy */}
          <div className="reveal">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm font-medium text-forest-700">
              <MapPin className="h-4 w-4" />
              <span>{agent.location}</span>
              <span className="text-forest-300">•</span>
              <BadgeCheck className="h-4 w-4" />
              <span>Verified DigitalFlyer SA agent</span>
            </div>

            <h1 className="mt-5 font-display text-4xl font-semibold leading-[1.05] text-ink sm:text-5xl lg:text-6xl">
              {agent.agentName}
            </h1>

            <p className="mt-2 text-lg font-medium text-forest-700">
              {agent.role}
            </p>

            <p className="mt-5 max-w-xl text-xl leading-snug text-ink/85 sm:text-2xl">
              {agent.tagline}
            </p>

            <p className="mt-4 max-w-lg text-base leading-relaxed text-ink/70">
              Tell me about your business and I will help you get the words and
              details right. The system builds your page, puts you on the
              marketplace, and gets your posts ready to share every month.
            </p>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <WhatsAppButton />
              <PricesButton />
            </div>
          </div>

          {/* photo */}
          <div className="reveal mx-auto w-full max-w-sm lg:max-w-none">
            <div className="relative">
              <div className="absolute -inset-3 -rotate-2 rounded-[2rem] bg-gradient-to-br from-forest-200/60 to-sand-300/60" />
              <div className="relative aspect-[4/5] overflow-hidden rounded-[1.75rem] border border-white/60 bg-sand-100 shadow-lift">
                {hasPhoto ? (
                  <img
                    src={agent.photoUrl}
                    alt={agent.agentName}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-sand-100 to-sand-200 text-forest-700">
                    <UserCircle className="h-20 w-20" strokeWidth={1.1} />
                    <span className="px-6 text-center text-sm font-medium text-forest-700/70">
                      {agent.firstName}'s photo appears here
                    </span>
                  </div>
                )}
              </div>
              <div className="absolute -bottom-4 -left-4 flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-soft sm:-left-6">
                <BadgeCheck className="h-5 w-5 text-forest-600" />
                <span className="text-sm font-semibold text-ink">
                  Active since {agent.activeSince}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

/* ----------------------------- problem + steps combined ----------------------------- */

const steps = [
  {
    n: "1",
    title: "You message me",
    body: "We talk about what your business does and who you want reaching you. No forms, no jargon — just a conversation.",
    icon: MessageCircle,
  },
  {
    n: "2",
    title: "I help you with the info",
    body: "I ask the right questions and help you put your words and details together. The system then builds your page automatically.",
    icon: HelpCircle,
  },
  {
    n: "3",
    title: "You approve and share it",
    body: "You see your page and approve it before anyone else does. One link for WhatsApp, Facebook, invoices, the back of your bakkie.",
    icon: Share2,
  },
];

function ProblemSteps() {
  return (
    <section className="bg-sand-100 py-14 sm:py-16">
      <div className="mx-auto max-w-5xl px-6">
        {/* problem — tight */}
        <div className="reveal max-w-2xl">
          <SectionLabel>The gap</SectionLabel>
          <p className="mt-4 font-display text-2xl leading-snug text-ink sm:text-[1.75rem]">
            Someone asks if you have a website and you are not sure what to say.
            A competitor with a worse product wins the job, because they had
            somewhere to send people.
          </p>
          <p className="mt-4 font-display text-xl font-medium text-forest-800 sm:text-2xl">
            That is the gap. Let us close it.
          </p>
        </div>

        {/* steps — directly under, no big jump */}
        <div className="reveal mt-10">
          <SectionLabel>How this actually goes</SectionLabel>
          <h2 className="mt-3 font-display text-2xl font-semibold text-ink sm:text-3xl">
            Three steps, and I am with you for all of them.
          </h2>
        </div>

        <div className="mt-7 grid gap-4 sm:grid-cols-3">
          {steps.map((s) => (
            <div
              key={s.n}
              className="reveal group rounded-2xl border border-sand-200 bg-white/70 p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-lift"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-forest-600 font-display text-base font-semibold text-white">
                  {s.n}
                </span>
                <s.icon className="h-5 w-5 text-forest-700" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold text-ink">
                {s.title}
              </h3>
              <p className="mt-1.5 text-[0.95rem] leading-relaxed text-ink/70">
                {s.body}
              </p>
            </div>
          ))}
        </div>

        <div className="reveal mt-8 text-center">
          <WhatsAppButton />
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- outcomes + portfolio combined ----------------------------- */

const outcomes = [
  { title: "Your own professional page", icon: FileText },
  { title: "A place on the marketplace", icon: MapPin },
  { title: "Branded posts every month", icon: Share2 },
  { title: "Real customer reviews", icon: Star },
];

function OutcomesPortfolio() {
  return (
    <section className="bg-forest-950 py-14 text-white sm:py-16">
      <div className="mx-auto max-w-5xl px-6">
        {/* outcomes */}
        <div className="reveal text-center">
          <SectionLabel tone="light">What you end up with</SectionLabel>
          <h2 className="mt-3 font-display text-2xl font-semibold sm:text-3xl">
            Everything you need to look like the real deal.
          </h2>
        </div>

        <div className="mt-7 grid gap-3 sm:grid-cols-2">
          {outcomes.map((o) => (
            <div
              key={o.title}
              className="reveal flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 backdrop-blur transition hover:bg-white/10"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest-500/20 text-forest-200">
                <o.icon className="h-5 w-5" />
              </span>
              <span className="font-display text-lg font-medium">
                {o.title}
              </span>
              <CheckCircle2 className="ml-auto h-5 w-5 text-forest-300" />
            </div>
          ))}
        </div>

        {/* portfolio — flows straight on, dark section continues */}
        <div className="reveal mt-12 text-center">
          <SectionLabel tone="light">
            Pages like the one you will get
          </SectionLabel>
          <h2 className="mt-3 font-display text-2xl font-semibold sm:text-3xl">
            Real South African businesses, live right now.
          </h2>
        </div>

        <div className="mt-7 grid gap-4 sm:grid-cols-3">
          {agent.portfolio.map((p) => (
            <a
              key={p.name}
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal group block overflow-hidden rounded-2xl border border-white/10 bg-white/5 backdrop-blur transition hover:-translate-y-1 hover:bg-white/10"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest-950/60 to-transparent" />
              </div>
              <div className="flex items-center justify-between px-4 py-3.5">
                <span className="font-display text-base font-semibold">
                  {p.name}
                </span>
                <ArrowRight className="h-4 w-4 text-forest-300 transition-transform group-hover:translate-x-1" />
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- bio ----------------------------- */

function Bio() {
  return (
    <section className="bg-sand-50 py-14 sm:py-16">
      <div className="mx-auto max-w-3xl px-6">
        <div className="reveal rounded-3xl border border-sand-200 bg-white/80 p-7 shadow-soft sm:p-10">
          <div className="flex items-center gap-3">
            <BadgeCheck className="h-6 w-6 text-forest-700" />
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-forest-700">
              Verified DigitalFlyer SA agent
            </span>
          </div>

          <p className="mt-5 text-lg leading-relaxed text-ink/85">
            {agent.bio}
          </p>

          <div className="mt-7 border-t border-sand-200 pt-5">
            <p className="flex items-center gap-2 text-sm font-semibold text-ink">
              <Sparkles className="h-4 w-4 text-forest-700" />
              {agent.firstName} also does
            </p>
            <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-2">
              {agent.alsoDoes.map((s) => (
                <li
                  key={s}
                  className="flex items-center gap-2 text-[0.95rem] text-ink/75"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-forest-500" />
                  {s}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm text-ink/50">
              These are {agent.firstName}'s own services, separate from
              DigitalFlyer SA.
            </p>
          </div>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <WhatsAppButton />
            <PricesButton />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- footer ----------------------------- */

function Footer() {
  return (
    <footer className="bg-forest-950 py-10 text-white/70">
      <div className="mx-auto max-w-5xl px-6">
        <div className="flex flex-col items-center justify-between gap-5 sm:flex-row">
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm">
            {agent.footerLinks.map((l) => (
              <a
                key={l.label}
                href={l.url}
                className="transition hover:text-white"
              >
                {l.label}
              </a>
            ))}
          </div>
          <div className="flex gap-3">
            <WhatsAppButton label="WhatsApp" className="!px-5 !py-2.5 !text-sm" />
            <PricesButton className="!px-5 !py-2.5 !text-sm" />
          </div>
        </div>
        <p className="mt-6 text-center text-xs text-white/40">
          © {new Date().getFullYear()} {agent.agentName} · DigitalFlyer SA
        </p>
      </div>
    </footer>
  );
}

/* ----------------------------- sticky + cookie ----------------------------- */

function StickyCta({ show }: { show: boolean }) {
  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 transform transition-transform duration-300 ${
        show ? "translate-y-0" : "translate-y-full"
      } sm:hidden`}
    >
      <div className="mx-3 mb-3 flex gap-2 rounded-2xl border border-sand-200 bg-white/95 p-2.5 shadow-lift backdrop-blur">
        <WhatsAppButton label="WhatsApp" className="!flex-1 !py-2.5 !text-sm" />
        <PricesButton className="!py-2.5 !text-sm" />
      </div>
    </div>
  );
}

function CookieBanner() {
  const [visible, setVisible] = useState(true);
  if (!visible) return null;
  return (
    <div className="fixed bottom-4 left-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 rounded-2xl border border-sand-200 bg-white/95 p-4 shadow-lift backdrop-blur sm:bottom-6">
      <button
        onClick={() => setVisible(false)}
        aria-label="Close"
        className="absolute right-3 top-3 text-ink/40 transition hover:text-ink"
      >
        <X className="h-4 w-4" />
      </button>
      <p className="pr-6 text-sm leading-relaxed text-ink/70">
        This page uses a tracking cookie to measure ad performance. You can
        accept or reject it. Either way, the page works exactly the same.
      </p>
      <div className="mt-3 flex shrink-0 items-center gap-3">
        <button
          onClick={() => setVisible(false)}
          className="rounded-full border border-sand-300 px-5 py-2 text-sm font-semibold text-ink transition hover:border-sand-400"
        >
          Reject
        </button>
        <button
          onClick={() => setVisible(false)}
          className="rounded-full bg-ink px-5 py-2 text-sm font-semibold text-white transition hover:bg-ink/90"
        >
          Accept
        </button>
      </div>
    </div>
  );
}

/* ----------------------------- app ----------------------------- */

function App() {
  useReveal();
  const showSticky = useStickyCta();
  const mainRef = useRef<HTMLElement>(null);

  return (
    <div className="min-h-screen bg-sand-50 text-ink">
      <Hero />
      <main ref={mainRef}>
        <ProblemSteps />
        <OutcomesPortfolio />
        <Bio />
      </main>
      <Footer />
      <StickyCta show={showSticky} />
      <CookieBanner />
    </div>
  );
}

export default App;
