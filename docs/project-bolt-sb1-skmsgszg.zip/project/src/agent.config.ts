/**
 * Agent profile configuration.
 *
 * To launch a new agent, edit the values below. The page rebuilds itself
 * from this object — no other files need to change.
 */

export type PortfolioItem = {
  name: string;
  url: string;
  image: string;
};

export type AgentConfig = {
  agentName: string;
  firstName: string;
  role: string;
  location: string;
  tagline: string;
  photoUrl: string;
  whatsappUrl: string;
  pricesUrl: string;
  activeSince: string;
  bio: string;
  alsoDoes: string[];
  portfolio: PortfolioItem[];
  footerLinks: { label: string; url: string }[];
};

export const agent: AgentConfig = {
  agentName: "Losaan Vd Westhuizen Meiring",
  firstName: "Losaan",
  role: "DigitalFlyer SA agent",
  location: "Marloth Park",
  tagline: "You are good at what you do. Let me handle the online part.",
  photoUrl: "", // drop in the agent's photo URL here
  whatsappUrl: "https://wa.me/27123456789",
  pricesUrl: "#prices",
  activeSince: "July 2026",
  bio: "I run JozyMee Marketing and Creative Solutions, so I know the gap you are in. I could get people interested in a business, and then there was nowhere good to send them. A Facebook page is not a home. That is why I do this, and it is why I would rather talk to you than have you fill in a form.",
  alsoDoes: [
    "Social media management",
    "Creative content and design",
    "Campaigns and promotions",
  ],
  portfolio: [
    {
      name: "Buffelskop",
      url: "#",
      image: "https://images.pexels.com/photos/2467558/pexels-photo-2467558.jpeg?auto=compress&cs=tinysrgb&w=800",
    },
    {
      name: "Helplift Network Vaal Triangle",
      url: "#",
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800",
    },
    {
      name: "Standing 365",
      url: "#",
      image: "https://images.pexels.com/photos/3760067/pexels-photo-3760067.jpeg?auto=compress&cs=tinysrgb&w=800",
    },
  ],
  footerLinks: [
    { label: "Marketplace", url: "#" },
    { label: "Shop", url: "#" },
    { label: "Privacy Policy", url: "#" },
    { label: "Terms & Conditions", url: "#" },
  ],
};
