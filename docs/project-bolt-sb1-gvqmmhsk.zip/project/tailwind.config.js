/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: '#1081B8',
          'blue-dark': '#0C6A97',
          'blue-light': '#E8F4FC',
          'blue-mid': '#1A9DD4',
        },
        accent: {
          DEFAULT: '#E8821A',
          hover: '#CF7116',
          light: '#FEF3E2',
        },
        neutral: {
          ink: '#1C2B3A',
          mid: '#4A5568',
          muted: '#718096',
          border: '#E2E8F0',
          light: '#F7F9FB',
          white: '#FFFFFF',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display': ['3.25rem', { lineHeight: '1.15', letterSpacing: '-0.02em' }],
        'display-sm': ['2.5rem', { lineHeight: '1.2', letterSpacing: '-0.015em' }],
        'headline': ['1.875rem', { lineHeight: '1.25', letterSpacing: '-0.01em' }],
        'title': ['1.375rem', { lineHeight: '1.35' }],
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
      },
      boxShadow: {
        'card': '0 1px 4px 0 rgba(28,43,58,0.08), 0 4px 16px 0 rgba(28,43,58,0.06)',
        'card-hover': '0 4px 12px 0 rgba(28,43,58,0.12), 0 12px 32px 0 rgba(28,43,58,0.08)',
      },
    },
  },
  plugins: [],
};
