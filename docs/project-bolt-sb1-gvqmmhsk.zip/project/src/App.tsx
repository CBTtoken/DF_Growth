import Navbar from '@/components/Navbar';
import CookieBanner from '@/components/CookieBanner';
import Hero from '@/components/Hero';
import WhyChoose from '@/components/WhyChoose';
import HowItWorks from '@/components/HowItWorks';
import RealOnlinePower from '@/components/RealOnlinePower';
import SoundFamiliar from '@/components/SoundFamiliar';
import MostVisitedPages from '@/components/MostVisitedPages';
import Pricing from '@/components/Pricing';
import DoMore from '@/components/DoMore';
import WhatYouGet from '@/components/WhatYouGet';
import FinalCTA from '@/components/FinalCTA';
import ContactForm from '@/components/ContactForm';
import Footer from '@/components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <WhyChoose />
        <HowItWorks />
        <RealOnlinePower />
        <SoundFamiliar />
        <MostVisitedPages />
        <Pricing />
        <DoMore />
        <WhatYouGet />
        <FinalCTA />
        <ContactForm />
      </main>
      <Footer />
      <CookieBanner />
    </div>
  );
}
