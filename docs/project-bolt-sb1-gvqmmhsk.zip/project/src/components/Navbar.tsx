import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'Marketplace', href: '#marketplace' },
  { label: 'Shop', href: '#shop' },
  { label: 'Events', href: '#do-more' },
  { label: 'Agents', href: '#do-more' },
  { label: 'FAQ', href: '#faq' },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-card border-b border-neutral-border' : 'bg-white/95 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 lg:h-16">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 shrink-0">
            <img
              src="/DF_Logo_Blue_Transparent.png"
              alt="DigitalFlyer"
              className="h-7 w-auto"
            />
            <span className="text-brand-blue font-bold text-sm tracking-tight hidden sm:block">
              Growth
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-neutral-mid hover:text-neutral-ink text-sm font-medium px-3 py-2 rounded-md transition-colors duration-150"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#"
              className="text-neutral-mid hover:text-neutral-ink text-sm font-medium px-3 py-2 rounded-md transition-colors duration-150 ml-1"
            >
              Log in
            </a>
          </nav>

          {/* Desktop CTA */}
          <div className="hidden lg:block">
            <a href="#pricing" className="btn-accent text-sm px-5 py-2.5">
              See Pricing
            </a>
          </div>

          {/* Mobile right */}
          <div className="flex items-center gap-2.5 lg:hidden">
            <a href="#pricing" className="btn-accent text-sm px-4 py-2">
              See Pricing
            </a>
            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="p-2 rounded-lg text-neutral-ink hover:bg-neutral-light transition-colors"
              aria-label="Toggle menu"
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="lg:hidden bg-white border-t border-neutral-border shadow-card">
          <nav className="flex flex-col px-4 py-3 gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-neutral-ink font-medium text-base py-2.5 px-3 rounded-lg hover:bg-neutral-light transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#"
              onClick={() => setMenuOpen(false)}
              className="text-neutral-mid font-medium text-base py-2.5 px-3 rounded-lg hover:bg-neutral-light transition-colors"
            >
              Log in
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
