import { useState } from 'react';
import { Send, ShieldCheck } from 'lucide-react';

export default function ContactForm() {
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="contact" className="bg-neutral-light py-10 lg:py-14">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-6">
          <p className="section-eyebrow">Get In Touch</p>
          <h2 className="section-heading text-2xl lg:text-3xl">Questions about DigitalFlyer?</h2>
          <p className="mt-1.5 text-sm text-neutral-mid leading-relaxed">
            We'll respond within one business day.
          </p>
        </div>

        {sent ? (
          <div className="bg-white border border-neutral-border rounded-2xl p-8 lg:p-10 shadow-card text-center">
            <div className="w-14 h-14 rounded-full bg-brand-blue-light flex items-center justify-center mx-auto mb-3">
              <Send size={24} className="text-brand-blue" />
            </div>
            <h3 className="text-lg font-bold text-neutral-ink mb-1.5">Message sent</h3>
            <p className="text-sm text-neutral-mid">
              Thanks for reaching out. We'll get back to you within one business day.
            </p>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-white border border-neutral-border rounded-2xl p-5 lg:p-6 shadow-card space-y-4"
          >
            <div>
              <label htmlFor="name" className="block text-sm font-semibold text-neutral-ink mb-1.5">
                Name
              </label>
              <input
                id="name"
                type="text"
                required
                className="w-full rounded-lg border border-neutral-border px-4 py-2.5 text-base text-neutral-ink placeholder-neutral-muted focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/20 focus:outline-none transition-colors"
                placeholder="Your name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-neutral-ink mb-1.5">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                className="w-full rounded-lg border border-neutral-border px-4 py-2.5 text-base text-neutral-ink placeholder-neutral-muted focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/20 focus:outline-none transition-colors"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-semibold text-neutral-ink mb-1.5">
                Phone <span className="text-neutral-muted font-normal">(optional)</span>
              </label>
              <input
                id="phone"
                type="tel"
                className="w-full rounded-lg border border-neutral-border px-4 py-2.5 text-base text-neutral-ink placeholder-neutral-muted focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/20 focus:outline-none transition-colors"
                placeholder="082 000 0000"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-semibold text-neutral-ink mb-1.5">
                Message <span className="text-neutral-muted font-normal">(optional)</span>
              </label>
              <textarea
                id="message"
                rows={4}
                className="w-full rounded-lg border border-neutral-border px-4 py-2.5 text-base text-neutral-ink placeholder-neutral-muted focus:border-brand-blue focus:ring-2 focus:ring-brand-blue/20 focus:outline-none transition-colors resize-y"
                placeholder="How can we help?"
              />
            </div>

            <button type="submit" className="btn-accent w-full">
              <Send size={18} />
              Send
            </button>

            <p className="flex items-center justify-center gap-1.5 text-xs text-neutral-muted pt-1">
              <ShieldCheck size={14} className="text-brand-blue" />
              Secure payment via Paystack
            </p>
          </form>
        )}
      </div>
    </section>
  );
}
