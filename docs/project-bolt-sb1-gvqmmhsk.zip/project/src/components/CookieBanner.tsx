import { useState } from 'react';
import { X } from 'lucide-react';

export default function CookieBanner() {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-neutral-ink text-white shadow-lg">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="text-sm text-white/90 leading-relaxed flex-1 pr-4">
            This page uses a tracking cookie to measure ad performance. You can accept or reject it,
            either way, the page works exactly the same.
          </p>
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => setVisible(false)}
              className="text-sm font-semibold text-white/80 hover:text-white underline underline-offset-2 transition-colors px-1 py-1"
            >
              Reject
            </button>
            <button
              onClick={() => setVisible(false)}
              className="text-sm font-semibold bg-brand-blue text-white px-5 py-2 rounded-lg hover:bg-brand-blue-dark transition-colors"
            >
              Accept
            </button>
            <button
              onClick={() => setVisible(false)}
              className="text-white/60 hover:text-white transition-colors p-1 ml-1"
              aria-label="Dismiss"
            >
              <X size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
