const footerLinks = [
  { label: 'Marketplace', href: '#marketplace' },
  { label: 'Shop', href: '#shop' },
  { label: 'Become an Agent', href: '#do-more' },
  { label: 'Privacy Policy', href: '#' },
  { label: 'Terms & Conditions', href: '#' },
];

export default function Footer() {
  return (
    <footer className="bg-neutral-ink text-white py-10 lg:py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row justify-between gap-6">
          {/* Logo */}
          <div className="max-w-xs">
            <img
              src="/DF_Logo_White_Transparent.png"
              alt="DigitalFlyer"
              className="h-8 w-auto mb-3"
            />
            <p className="text-sm text-white/70 leading-relaxed">
              A professional online presence, lead generation, and a small ecosystem of tools for
              South African businesses, all in one subscription.
            </p>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap gap-x-6 gap-y-2.5">
            {footerLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm text-white/80 hover:text-white transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="mt-8 pt-5 border-t border-white/10 flex flex-col sm:flex-row justify-between gap-2">
          <p className="text-xs text-white/50">
            © {new Date().getFullYear()} DigitalFlyer. All rights reserved.
          </p>
          <p className="text-xs text-white/50">Built for South African businesses.</p>
        </div>
      </div>
    </footer>
  );
}
