import { useState } from 'react';
import { Check, Sparkles, ArrowRight, Rocket } from 'lucide-react';

type Plan = {
  name: string;
  badge?: string;
  monthly: number | null;
  annual: number | null;
  freeTrial?: boolean;
  comingSoon?: boolean;
  tagline: string;
  features: string[];
  cta: string;
  note: string;
  highlight?: boolean;
};

const plans: Plan[] = [
  {
    name: 'Foundation',
    freeTrial: true,
    monthly: 100,
    annual: 100,
    tagline: 'Perfect for businesses ready to build a professional online presence.',
    features: [
      'Professional Business Page',
      'Marketplace Listing',
      'Lead Generation Page',
      'Business Profile',
      'Monthly Digital Asset',
      'Ready To Share Anywhere',
      'RE:Biz Nomads Community',
      'BizUp In-Chat Payments',
    ],
    cta: 'Start Your Free Trial',
    note: 'No card required',
  },
  {
    name: 'Growth',
    badge: 'Most popular',
    monthly: 180,
    annual: 180,
    tagline: "Ready to reach more customers? Everything in Foundation, plus:",
    features: [
      'Campaign Landing Pages',
      'Performance Tracking',
      'Marketing Assets',
      'Monthly Optimisation',
      'Growth Reporting',
      'Booking & Shop Tools',
      'Marketplace Listing',
      'RE:Biz Nomads Community',
      'BizUp In-Chat Payments',
    ],
    cta: 'Start Growing',
    note: 'Secure payment via Paystack',
    highlight: true,
  },
  {
    name: 'Enterprise',
    comingSoon: true,
    monthly: null,
    annual: null,
    tagline: 'For businesses ready to scale. Everything in Growth, plus:',
    features: ['Advanced Campaign Management', 'Priority Support', 'Custom Solutions'],
    cta: 'Contact Us',
    note: 'Full Meta + Google ad management is on its way. Get in touch and we\'ll let you know the moment it\'s ready.',
  },
];

function ConsentCheckboxes() {
  return (
    <div className="mt-4 pt-4 border-t border-neutral-border space-y-2.5">
      <label className="flex items-start gap-2.5 cursor-pointer">
        <input
          type="checkbox"
          className="mt-0.5 w-4 h-4 rounded border-neutral-border text-brand-blue focus:ring-brand-blue"
        />
        <span className="text-xs text-neutral-mid leading-relaxed">
          I have read and agree to the{' '}
          <a href="#" className="text-brand-blue underline underline-offset-2">Privacy Policy</a> and{' '}
          <a href="#" className="text-brand-blue underline underline-offset-2">Terms &amp; Conditions</a>
        </span>
      </label>
      <label className="flex items-start gap-2.5 cursor-pointer">
        <input
          type="checkbox"
          className="mt-0.5 w-4 h-4 rounded border-neutral-border text-brand-blue focus:ring-brand-blue"
          defaultChecked={false}
        />
        <span className="text-xs text-neutral-mid leading-relaxed">
          Yes, send me occasional updates via email or WhatsApp
        </span>
      </label>
    </div>
  );
}

export default function Pricing() {
  const [annual, setAnnual] = useState(false);

  return (
    <section id="pricing" className="bg-white py-10 lg:py-14 border-b border-neutral-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6 lg:mb-7">
          <div>
            <p className="section-eyebrow">Pricing</p>
            <h2 className="section-heading text-2xl lg:text-3xl">Start Where Your Business Is Today</h2>
            <p className="mt-1.5 text-sm text-neutral-mid leading-relaxed max-w-xl">
              You don't need a huge budget or an expensive agency. Choose the package that fits today,
              upgrade whenever you're ready.
            </p>
          </div>

          {/* Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <span className={`text-sm font-bold ${!annual ? 'text-neutral-ink' : 'text-neutral-muted'}`}>
              Monthly
            </span>
            <button
              onClick={() => setAnnual((v) => !v)}
              className="relative w-14 h-7 rounded-full bg-neutral-border transition-colors duration-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-blue"
              role="switch"
              aria-checked={annual}
              aria-label="Toggle annual billing"
            >
              <span
                className={`absolute top-1 left-1 w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-200 ${
                  annual ? 'translate-x-7 bg-brand-blue' : ''
                }`}
              />
            </button>
            <span className={`text-sm font-bold ${annual ? 'text-neutral-ink' : 'text-neutral-muted'}`}>
              Annual
            </span>
          </div>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-5 items-stretch">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col rounded-2xl border-2 p-5 lg:p-6 transition-all duration-200 ${
                plan.highlight
                  ? 'border-brand-blue shadow-card-hover lg:scale-[1.02]'
                  : 'border-neutral-border shadow-card'
              } ${plan.comingSoon ? 'bg-neutral-light' : 'bg-white'}`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1.5 bg-brand-blue text-white text-xs font-bold px-3.5 py-1.5 rounded-full whitespace-nowrap">
                    <Sparkles size={13} />
                    {plan.badge}
                  </span>
                </div>
              )}

              <h3 className="text-lg font-bold text-neutral-ink">{plan.name}</h3>

              {/* Price / trial badge */}
              <div className="mt-2.5 min-h-[2.5rem]">
                {plan.freeTrial ? (
                  <div className="inline-flex items-center gap-2 bg-accent text-white font-bold text-sm px-3.5 py-2 rounded-lg shadow-sm shadow-accent/20">
                    <Rocket size={15} className="shrink-0" />
                    Free for 7 days
                    <span className="text-white/80 font-medium ml-0.5">· then R100/mo</span>
                  </div>
                ) : plan.comingSoon ? (
                  <span className="text-2xl font-bold text-neutral-muted">Coming soon</span>
                ) : (
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-extrabold text-neutral-ink">
                      R{annual ? plan.annual : plan.monthly}
                    </span>
                    <span className="text-sm text-neutral-muted font-medium">/month</span>
                  </div>
                )}
              </div>

              <p className="mt-2.5 text-sm text-neutral-mid leading-relaxed min-h-[2.5rem]">
                {plan.tagline}
              </p>

              <ul className="mt-4 space-y-2 flex-1">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5">
                    <Check size={16} className="text-brand-blue shrink-0 mt-0.5" strokeWidth={2.5} />
                    <span className="text-sm text-neutral-ink leading-snug">{f}</span>
                  </li>
                ))}
              </ul>

              {!plan.comingSoon && <ConsentCheckboxes />}

              <div className="mt-5">
                <a
                  href={plan.comingSoon ? '#contact' : '#'}
                  className={`w-full ${plan.highlight ? 'btn-accent' : 'btn-outline'} justify-center`}
                >
                  {plan.cta}
                  {!plan.comingSoon && <ArrowRight size={18} />}
                </a>
                <p className="mt-2.5 text-xs text-neutral-muted text-center leading-relaxed">
                  {plan.note}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
