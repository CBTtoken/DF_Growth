import { useState, useCallback } from 'react';
import ShopHero from '@/components/shop/ShopHero';
import CategoryNav from '@/components/shop/CategoryNav';
import ProductGrid from '@/components/shop/ProductGrid';
import CartDrawer from '@/components/shop/CartDrawer';
import type { Product, CartItem, ProductCategory } from '@/data/products';

interface Props {
  cartItemCount: number;
  onCartCountChange: (n: number) => void;
  cartOpen: boolean;
  onOpenCart: () => void;
  onCloseCart: () => void;
}

export default function ShopPage({ onCartCountChange, cartOpen, onCloseCart }: Props) {
  const [activeCategory, setActiveCategory] = useState<ProductCategory | 'All'>('All');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const cartIds = cartItems.map((i) => i.product.id);

  const handleAddToCart = useCallback((product: Product) => {
    setCartItems((prev) => {
      const exists = prev.find((i) => i.product.id === product.id);
      const updated = exists
        ? prev.map((i) => i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i)
        : [...prev, { product, quantity: 1 }];
      onCartCountChange(updated.reduce((s, i) => s + i.quantity, 0));
      return updated;
    });
  }, [onCartCountChange]);

  const handleUpdateQty = useCallback((id: string, qty: number) => {
    setCartItems((prev) => {
      const updated = prev.map((i) => i.product.id === id ? { ...i, quantity: qty } : i);
      onCartCountChange(updated.reduce((s, i) => s + i.quantity, 0));
      return updated;
    });
  }, [onCartCountChange]);

  const handleRemove = useCallback((id: string) => {
    setCartItems((prev) => {
      const updated = prev.filter((i) => i.product.id !== id);
      onCartCountChange(updated.reduce((s, i) => s + i.quantity, 0));
      return updated;
    });
  }, [onCartCountChange]);

  return (
    <div className="min-h-screen bg-surface-muted">
      <ShopHero />
      <CategoryNav active={activeCategory} onChange={setActiveCategory} />
      <ProductGrid activeCategory={activeCategory} cartIds={cartIds} onAddToCart={handleAddToCart} />

      {cartOpen && (
        <CartDrawer
          items={cartItems}
          onClose={onCloseCart}
          onUpdateQty={handleUpdateQty}
          onRemove={handleRemove}
          onCheckout={() => {
            alert('Checkout flow — connect your payment gateway here!');
            onCloseCart();
          }}
        />
      )}
    </div>
  );
}
