import { SlidersHorizontal, LayoutGrid, List, Ticket } from 'lucide-react';
import { useState } from 'react';
import EventCard from '@/components/EventCard';
import CalendarToggle from '@/components/CalendarToggle';
import { events, type Event, type EventFilter } from '@/data/events';

interface Props {
  selectedIds: string[];
  onBook: (event: Event) => void;
}

const CATEGORIES = ['All', 'Market', 'Workshop', 'Festival', 'Networking', 'Production'];
const PROVINCES = ['All Provinces', 'Gauteng', 'Western Cape', 'KwaZulu-Natal'];

export default function EventsGrid({ selectedIds, onBook }: Props) {
  const [filter, setFilter] = useState<EventFilter>('all-upcoming');
  const [category, setCategory] = useState('All');
  const [province, setProvince] = useState('All Provinces');
  const [layout, setLayout] = useState<'grid' | 'list'>('grid');

  const counts: Record<EventFilter, number> = {
    'this-weekend': events.filter((e) => e.filter.includes('this-weekend')).length,
    'this-month':   events.filter((e) => e.filter.includes('this-month')).length,
    'all-upcoming': events.filter((e) => e.filter.includes('all-upcoming')).length,
  };

  const filtered = events.filter((e) => {
    if (!e.filter.includes(filter)) return false;
    if (category !== 'All' && e.category !== category) return false;
    if (province !== 'All Provinces' && e.province !== province) return false;
    return true;
  });

  return (
    <section id="events" className="bg-surface-muted py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section header */}
        <div className="flex flex-col sm:flex-row sm:items-end gap-4 mb-6">
          <div>
            <p className="text-df-500 text-xs font-bold uppercase tracking-widest mb-1">Events Directory</p>
            <h2 className="text-ink font-black text-3xl leading-tight">What's On Near You</h2>
          </div>
          <p className="sm:ml-auto text-ink-muted text-sm">
            Showing <span className="text-ink font-bold">{filtered.length}</span> events
          </p>
        </div>

        {/* Filters bar */}
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center mb-8">
          <CalendarToggle active={filter} onChange={setFilter} counts={counts} />

          <div className="flex flex-wrap gap-2 lg:ml-auto items-center">
            {/* Category chips */}
            <div className="flex items-center gap-1 bg-white border border-surface-border rounded-xl p-1 shadow-sm">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    category === cat
                      ? 'bg-df-500 text-white shadow-sm'
                      : 'text-ink-secondary hover:text-df-500 hover:bg-df-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Province select */}
            <div className="relative">
              <SlidersHorizontal className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-faint pointer-events-none" />
              <select
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                className="bg-white border border-surface-border text-ink-secondary text-xs font-medium rounded-xl pl-7 pr-3 py-2 appearance-none focus:outline-none focus:border-df-400 focus:ring-2 focus:ring-df-100 cursor-pointer shadow-sm"
              >
                {PROVINCES.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            {/* Layout toggle */}
            <div className="flex items-center bg-white border border-surface-border rounded-xl overflow-hidden shadow-sm">
              <button
                onClick={() => setLayout('grid')}
                className={`p-2 transition-colors ${layout === 'grid' ? 'bg-df-500 text-white' : 'text-ink-muted hover:text-df-500'}`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setLayout('list')}
                className={`p-2 transition-colors ${layout === 'list' ? 'bg-df-500 text-white' : 'text-ink-muted hover:text-df-500'}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Grid / List */}
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 bg-white border border-surface-border rounded-2xl flex items-center justify-center mb-4 shadow-sm">
              <SlidersHorizontal className="w-7 h-7 text-ink-faint" />
            </div>
            <p className="text-ink font-bold text-lg">No events found</p>
            <p className="text-ink-muted text-sm mt-1">Try adjusting your filters</p>
            <button
              onClick={() => { setCategory('All'); setProvince('All Provinces'); setFilter('all-upcoming'); }}
              className="mt-4 text-df-500 hover:text-df-700 text-sm font-semibold underline underline-offset-2"
            >
              Clear all filters
            </button>
          </div>
        ) : layout === 'grid' ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onBook={onBook}
                isSelected={selectedIds.includes(event.id)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {filtered.map((event) => (
              <ListEventRow
                key={event.id}
                event={event}
                onBook={onBook}
                isSelected={selectedIds.includes(event.id)}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function ListEventRow({ event, onBook, isSelected }: { event: Event; onBook: (e: Event) => void; isSelected: boolean }) {
  const isFree = event.price === 0;
  const pct = Math.round((event.seatsLeft / event.totalSeats) * 100);
  const barColor = pct <= 10 ? 'bg-rose-500' : pct <= 30 ? 'bg-amber-500' : 'bg-emerald-500';

  return (
    <article
      className={`
        group bg-white border rounded-2xl overflow-hidden flex transition-all duration-200
        hover:border-df-400 hover:shadow-df-md
        ${isSelected ? 'border-df-500 shadow-df-md ring-2 ring-df-100' : 'border-surface-border shadow-sm'}
      `}
    >
      <div className="relative w-40 sm:w-56 flex-shrink-0 overflow-hidden bg-surface-muted">
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-sm border border-surface-border rounded-xl overflow-hidden text-center min-w-[48px] shadow-md">
          <div className="bg-df-500 px-1.5 pt-0.5 pb-0">
            <p className="text-white text-[8px] font-black tracking-widest uppercase">{event.dateLabel.split(' ')[0]}</p>
          </div>
          <div className="px-1.5 py-0.5">
            <p className="text-ink font-black text-lg leading-none">{event.dateLabel.split(' ')[1]}</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row flex-1 p-4 gap-4">
        <div className="flex-1 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <span className="text-df-600 text-[10px] font-bold uppercase tracking-widest">{event.category}</span>
            {isFree && (
              <span className="text-emerald-700 text-[10px] font-bold border border-emerald-200 bg-emerald-50 rounded-full px-2 py-0.5">
                Free
              </span>
            )}
          </div>
          <h3 className="text-ink font-black text-base leading-tight group-hover:text-df-600 transition-colors">
            {event.title}
          </h3>
          <p className="text-ink-muted text-xs line-clamp-1">{event.subtitle}</p>
          <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-ink-secondary text-xs">
            <span>{event.timeStart} – {event.timeEnd}</span>
            <span>{event.venue}, {event.city}</span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex-1 h-1.5 bg-surface-subtle rounded-full overflow-hidden">
              <div className={`h-full rounded-full ${barColor}`} style={{ width: `${100 - pct}%` }} />
            </div>
            <span className="text-ink-muted text-xs whitespace-nowrap">{event.seatsLeft} left</span>
          </div>
        </div>

        <div className="flex sm:flex-col items-center sm:items-stretch justify-between sm:justify-center gap-3 sm:w-36 flex-shrink-0">
          {!isFree && (
            <p className="text-ink font-black text-xl text-right sm:text-center">R{event.price}</p>
          )}
          <button
            onClick={() => onBook(event)}
            className={`
              flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl font-black text-sm w-full transition-all
              ${isSelected
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                : 'bg-df-500 hover:bg-df-600 text-white shadow-df-sm'
              }
            `}
          >
            <Ticket className="w-3.5 h-3.5" />
            {isSelected ? 'Added' : isFree ? 'Free Ticket' : 'Book Slot'}
          </button>
        </div>
      </div>
    </article>
  );
}

