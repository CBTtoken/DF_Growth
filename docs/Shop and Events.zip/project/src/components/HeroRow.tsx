import { ArrowRight, CheckCircle2, Megaphone, Users, TrendingUp } from 'lucide-react';

const PERKS = [
  { icon: CheckCircle2, label: 'Free listing — always' },
  { icon: Users, label: 'Reach 40,000+ locals' },
  { icon: TrendingUp, label: 'Real-time ticket tracking' },
];

export default function HeroRow() {
  return (
    <section className="bg-white border-b border-surface-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid lg:grid-cols-2 gap-6 items-stretch">

          {/* Left — value proposition */}
          <div className="flex flex-col justify-center gap-5">
            <div className="inline-flex items-center gap-2 bg-df-50 border border-df-200 rounded-full px-3 py-1 w-fit">
              <span className="w-2 h-2 rounded-full bg-df-500 animate-pulse" />
              <span className="text-df-600 text-xs font-semibold tracking-wide uppercase">Live Events Near You</span>
            </div>

            <h1 className="text-ink font-black text-4xl lg:text-5xl leading-[1.05] tracking-tight">
              Discover Local{' '}
              <span className="text-df-500">Markets,</span>{' '}
              <span className="text-df-500">Workshops</span>{' '}
              &amp; Community Events
            </h1>

            <p className="text-ink-secondary text-base leading-relaxed max-w-lg">
              South Africa's fastest-growing free events directory. Find craft markets,
              business bootcamps, cultural festivals, and production workshops — all in one place.
            </p>

            <div className="flex flex-wrap gap-3">
              <a
                href="#events"
                className="bg-df-500 hover:bg-df-600 active:bg-df-700 text-white font-bold text-sm px-6 py-3 rounded-xl transition-all flex items-center gap-2 group shadow-df-md"
              >
                Browse All Events
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </a>
              <button className="border border-surface-border hover:border-df-400 bg-surface-muted hover:bg-df-50 text-ink-secondary hover:text-df-600 font-semibold text-sm px-6 py-3 rounded-xl transition-all">
                View Map
              </button>
            </div>

            <div className="flex flex-wrap gap-4 pt-1">
              {PERKS.map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-1.5 text-ink-muted text-xs">
                  <Icon className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right — list your event card */}
          <div className="relative rounded-2xl overflow-hidden border border-df-200 bg-gradient-to-br from-df-500 to-df-700 p-7 flex flex-col justify-between gap-6 shadow-df-lg">
            {/* Subtle overlay pattern */}
            <div className="absolute inset-0 pointer-events-none opacity-10"
              style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize: '28px 28px' }}
            />

            <div className="relative">
              <div className="flex items-start gap-3 mb-4">
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-2.5 flex-shrink-0 border border-white/30">
                  <Megaphone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-df-100 text-xs font-semibold uppercase tracking-widest mb-0.5">
                    Event Organiser?
                  </p>
                  <h2 className="text-white font-black text-xl leading-tight">
                    List your event on DigitalFlyer at no cost
                  </h2>
                </div>
              </div>

              <p className="text-df-100 text-sm leading-relaxed">
                Reach thousands of engaged locals across Gauteng, Western Cape &amp; KwaZulu-Natal.
                Free listings, real-time seat management, and instant ticket delivery.
              </p>
            </div>

            <div className="relative flex flex-col gap-3">
              <div className="grid grid-cols-3 gap-2 text-center">
                {[
                  { value: '9,400+', label: 'Events Listed' },
                  { value: '40K+', label: 'Monthly Visitors' },
                  { value: 'R0', label: 'Listing Cost' },
                ].map(({ value, label }) => (
                  <div key={label} className="bg-white/15 border border-white/25 rounded-xl py-3 px-2 backdrop-blur-sm">
                    <p className="text-white font-black text-lg leading-none">{value}</p>
                    <p className="text-df-100 text-xs mt-1">{label}</p>
                  </div>
                ))}
              </div>

              <a
                href="#"
                className="w-full bg-white hover:bg-df-50 text-df-600 font-black text-base py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg group"
              >
                <Megaphone className="w-4 h-4" />
                List My Event — It's Free
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </a>
              <p className="text-center text-df-200 text-xs">No credit card. No setup fee. Live in minutes.</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
