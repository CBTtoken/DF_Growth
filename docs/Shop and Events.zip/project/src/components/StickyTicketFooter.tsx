import { Ticket, X, ArrowRight, ShoppingBag } from 'lucide-react';
import type { Event } from '@/data/events';

interface Props {
  selected: Event[];
  onRemove: (id: string) => void;
  onCheckout: () => void;
}

export default function StickyTicketFooter({ selected, onRemove, onCheckout }: Props) {
  if (selected.length === 0) return null;

  const totalCost = selected.reduce((sum, e) => sum + e.price, 0);
  const freeCount = selected.filter((e) => e.price === 0).length;
  const paidCount = selected.length - freeCount;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 pointer-events-none">
      <div className="pointer-events-auto bg-white/95 backdrop-blur-md border-t border-surface-border shadow-[0_-4px_24px_rgba(30,157,200,0.12)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center gap-4">

            {/* Ticket count badge */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="relative">
                <div className="bg-df-500 rounded-xl p-2">
                  <ShoppingBag className="w-5 h-5 text-white" />
                </div>
                <span className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-white text-[10px] font-black rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                  {selected.length}
                </span>
              </div>
              <div className="hidden sm:block">
                <p className="text-ink font-bold text-sm leading-none">
                  {selected.length} ticket{selected.length > 1 ? 's' : ''} selected
                </p>
                <p className="text-ink-muted text-xs mt-0.5">
                  {freeCount > 0 && `${freeCount} free`}
                  {freeCount > 0 && paidCount > 0 && ' · '}
                  {paidCount > 0 && `${paidCount} paid`}
                </p>
              </div>
            </div>

            {/* Ticket chips */}
            <div className="flex-1 flex items-center gap-2 overflow-x-auto scrollbar-none min-w-0">
              {selected.map((event) => (
                <div
                  key={event.id}
                  className="flex items-center gap-1.5 bg-surface-muted border border-surface-border rounded-lg px-2.5 py-1.5 flex-shrink-0"
                >
                  <Ticket className="w-3 h-3 text-df-500 flex-shrink-0" />
                  <span className="text-ink text-xs font-semibold whitespace-nowrap max-w-[120px] truncate">
                    {event.title}
                  </span>
                  <span className="text-ink-muted text-xs whitespace-nowrap">
                    {event.price === 0 ? 'Free' : `R${event.price}`}
                  </span>
                  <button
                    onClick={() => onRemove(event.id)}
                    className="ml-1 text-ink-faint hover:text-rose-500 transition-colors flex-shrink-0"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>

            {/* Total + CTA */}
            <div className="flex items-center gap-3 flex-shrink-0">
              <div className="hidden sm:block text-right">
                <p className="text-ink-muted text-xs">Total</p>
                <p className="text-ink font-black text-lg leading-none">
                  {totalCost === 0 ? 'Free' : `R${totalCost}`}
                </p>
              </div>
              <button
                onClick={onCheckout}
                className="flex items-center gap-2 bg-df-500 hover:bg-df-600 active:bg-df-700 text-white font-black text-sm px-5 py-3 rounded-xl transition-all shadow-df-md group"
              >
                Checkout
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
