import { Calendar, CalendarDays, Infinity as InfinityIcon } from 'lucide-react';
import type { EventFilter } from '@/data/events';

interface Props {
  active: EventFilter;
  onChange: (f: EventFilter) => void;
  counts: Record<EventFilter, number>;
}

const FILTERS: { id: EventFilter; label: string; icon: React.ElementType }[] = [
  { id: 'this-weekend', label: 'This Weekend', icon: Calendar },
  { id: 'this-month', label: 'This Month', icon: CalendarDays },
  { id: 'all-upcoming', label: 'All Upcoming', icon: InfinityIcon },
];

export default function CalendarToggle({ active, onChange, counts }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-1 bg-surface-muted border border-surface-border rounded-2xl p-1 w-fit">
      {FILTERS.map(({ id, label, icon: Icon }) => {
        const isActive = active === id;
        return (
          <button
            key={id}
            onClick={() => onChange(id)}
            className={`
              flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all
              ${isActive
                ? 'bg-df-500 text-white shadow-df-sm'
                : 'text-ink-secondary hover:text-df-500 hover:bg-df-50'
              }
            `}
          >
            <Icon className="w-4 h-4" />
            <span>{label}</span>
            <span
              className={`
                text-xs font-bold rounded-full px-1.5 py-0.5 leading-none min-w-[1.4rem] text-center
                ${isActive ? 'bg-white/25 text-white' : 'bg-surface-border text-ink-muted'}
              `}
            >
              {counts[id]}
            </span>
          </button>
        );
      })}
    </div>
  );
}
