import { Menu, X, Search, ShoppingCart, CalendarDays, Store } from 'lucide-react';
import { useState } from 'react';

type Page = 'events' | 'shop';

interface Props {
  page: Page;
  onNavigate: (p: Page) => void;
  cartCount: number;
  onOpenCart: () => void;
}

export default function Navbar({ page, onNavigate, cartCount, onOpenCart }: Props) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-surface-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">

          {/* Logo + page switcher (always visible) */}
          <div className="flex items-center gap-3 min-w-0">
            <a
              href="#"
              onClick={(e) => { e.preventDefault(); onNavigate('events'); }}
              className="flex items-center h-10 flex-shrink-0"
            >
              <img
                src="/assets/logos/DF_Logo_Blue_Transparent.png"
                alt="DigitalFlyer"
                className="h-9 w-auto object-contain"
              />
              <span className="ml-2 hidden sm:block text-ink-secondary text-xs font-semibold border border-surface-border rounded px-1.5 py-0.5 tracking-wide uppercase">
                Growth
              </span>
            </a>

            {/* Page switcher — always visible, compact on mobile */}
            <nav className="flex items-center bg-surface-muted border border-surface-border rounded-xl p-0.5 gap-0.5 flex-shrink-0">
              <button
                onClick={() => onNavigate('events')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                  page === 'events'
                    ? 'bg-white text-df-600 shadow-sm border border-surface-border'
                    : 'text-ink-secondary hover:text-df-500'
                }`}
              >
                <CalendarDays className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span className="hidden xs:inline sm:inline">Events</span>
              </button>
              <button
                onClick={() => onNavigate('shop')}
                className={`flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                  page === 'shop'
                    ? 'bg-df-500 text-white shadow-df-sm'
                    : 'text-ink-secondary hover:text-df-500 hover:bg-df-50'
                }`}
              >
                <Store className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span>Shop</span>
              </button>
            </nav>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <button className="hidden sm:flex items-center justify-center text-ink-muted hover:text-df-500 transition-colors p-2 rounded-lg hover:bg-df-50">
              <Search className="w-4 h-4" />
            </button>

            {/* Cart icon — only on shop page */}
            {page === 'shop' && (
              <button
                onClick={onOpenCart}
                className="relative flex items-center justify-center text-ink-muted hover:text-df-500 transition-colors p-2 rounded-lg hover:bg-df-50"
              >
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-df-500 text-white text-[10px] font-black rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1 shadow">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </button>
            )}

            <a
              href="#"
              className="hidden sm:block bg-df-500 hover:bg-df-600 text-white text-sm font-bold px-4 py-2 rounded-lg transition-colors shadow-df-sm whitespace-nowrap"
            >
              {page === 'events' ? 'List Event Free' : 'Sell With Us'}
            </a>

            <button
              className="lg:hidden text-ink-muted hover:text-df-500 p-1"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="lg:hidden border-t border-surface-border py-4 flex flex-col gap-2">
            {['Markets', 'Workshops', 'About'].map((item) => (
              <a
                key={item}
                href="#"
                className="text-ink-secondary hover:text-df-500 text-sm font-medium transition-colors px-1 py-1"
              >
                {item}
              </a>
            ))}
            <a
              href="#"
              className="bg-df-500 hover:bg-df-600 text-white text-sm font-bold px-4 py-2.5 rounded-lg transition-colors text-center mt-1 shadow-df-sm"
            >
              {page === 'events' ? 'List Your Event Free' : 'Sell With Us'}
            </a>
          </div>
        )}
      </div>
    </header>
  );
}
