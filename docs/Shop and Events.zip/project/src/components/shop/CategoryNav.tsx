import {
  Grid, FileText, Share2, Award, TrendingUp, Wrench, Layout, Camera, Video, Star,
} from 'lucide-react';
import type { ProductCategory } from '@/data/products';
import { SHOP_CATEGORIES } from '@/data/products';

const ICON_MAP: Record<string, React.ElementType> = {
  grid: Grid,
  'file-text': FileText,
  'share-2': Share2,
  award: Award,
  'trending-up': TrendingUp,
  tool: Wrench,
  layout: Layout,
  camera: Camera,
  video: Video,
};

interface Props {
  active: ProductCategory | 'All';
  onChange: (c: ProductCategory | 'All') => void;
}

export default function CategoryNav({ active, onChange }: Props) {
  return (
    <div className="bg-white border-b border-surface-border sticky top-16 z-40 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-2">
          {SHOP_CATEGORIES.map(({ id, label, icon, count }) => {
            const Icon = ICON_MAP[icon] ?? Grid;
            const isActive = active === id;
            return (
              <button
                key={id}
                onClick={() => onChange(id as ProductCategory | 'All')}
                className={`
                  flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap flex-shrink-0 transition-all
                  ${isActive
                    ? 'bg-df-500 text-white shadow-df-sm'
                    : 'text-ink-secondary hover:text-df-500 hover:bg-df-50'
                  }
                `}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
                <span
                  className={`text-[10px] font-bold rounded-full px-1.5 py-0.5 leading-none min-w-[1.3rem] text-center ${
                    isActive ? 'bg-white/25 text-white' : 'bg-surface-border text-ink-muted'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}

          {/* Rating quick-filter */}
          <div className="ml-auto pl-4 border-l border-surface-border flex items-center gap-1 flex-shrink-0">
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="text-ink-secondary text-xs font-semibold whitespace-nowrap">Top Rated Only</span>
            <label className="relative inline-flex items-center cursor-pointer ml-1">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-8 h-4.5 bg-surface-border peer-checked:bg-df-500 rounded-full transition-colors after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:after:translate-x-3.5 after:shadow-sm" />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
