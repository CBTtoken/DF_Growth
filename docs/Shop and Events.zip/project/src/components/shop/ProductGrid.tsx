import { SlidersHorizontal, LayoutGrid, List, ChevronDown, Star, X, ShoppingCart } from 'lucide-react';
import { useState, useMemo } from 'react';
import ProductCard from '@/components/shop/ProductCard';
import { products, type Product, type ProductCategory } from '@/data/products';

interface Props {
  activeCategory: ProductCategory | 'All';
  cartIds: string[];
  onAddToCart: (p: Product) => void;
}

type SortKey = 'popular' | 'price-asc' | 'price-desc' | 'rating' | 'newest';

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: 'popular', label: 'Most Popular' },
  { value: 'rating', label: 'Highest Rated' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'newest', label: 'Newest First' },
];

const PRICE_RANGES = [
  { label: 'All Prices', min: 0, max: Infinity },
  { label: 'Under R500', min: 0, max: 500 },
  { label: 'R500 – R1,000', min: 500, max: 1000 },
  { label: 'R1,000 – R2,500', min: 1000, max: 2500 },
  { label: 'R2,500+', min: 2500, max: Infinity },
];

export default function ProductGrid({ activeCategory, cartIds, onAddToCart }: Props) {
  const [sort, setSort] = useState<SortKey>('popular');
  const [priceRange, setPriceRange] = useState(0);
  const [onlySale, setOnlySale] = useState(false);
  const [onlyNew, setOnlyNew] = useState(false);
  const [minRating, setMinRating] = useState(0);
  const [layout, setLayout] = useState<'grid' | 'list'>('grid');
  const [sortOpen, setSortOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const range = PRICE_RANGES[priceRange];

  const filtered = useMemo(() => {
    let list = [...products];
    if (activeCategory !== 'All') list = list.filter((p) => p.category === activeCategory);
    list = list.filter((p) => p.price >= range.min && p.price <= range.max);
    if (onlySale) list = list.filter((p) => p.isSale);
    if (onlyNew) list = list.filter((p) => p.isNew);
    if (minRating > 0) list = list.filter((p) => p.rating >= minRating);
    switch (sort) {
      case 'rating': return list.sort((a, b) => b.rating - a.rating);
      case 'price-asc': return list.sort((a, b) => a.price - b.price);
      case 'price-desc': return list.sort((a, b) => b.price - a.price);
      case 'newest': return list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      default: return list.sort((a, b) => b.reviewCount - a.reviewCount);
    }
  }, [activeCategory, sort, priceRange, onlySale, onlyNew, minRating, range.min, range.max]);

  const activeFilterCount = [onlySale, onlyNew, priceRange > 0, minRating > 0].filter(Boolean).length;

  const FilterPanel = () => (
    <div className="flex flex-col gap-6">
      {/* Price */}
      <div>
        <p className="text-ink text-xs font-black uppercase tracking-widest mb-3">Price Range</p>
        <div className="flex flex-col gap-2">
          {PRICE_RANGES.map((r, i) => (
            <label key={r.label} className="flex items-center gap-2 cursor-pointer group">
              <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all flex-shrink-0 ${
                priceRange === i ? 'border-df-500 bg-df-500' : 'border-surface-border group-hover:border-df-400'
              }`}>
                {priceRange === i && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
              </div>
              <input type="radio" className="sr-only" checked={priceRange === i} onChange={() => setPriceRange(i)} />
              <span className={`text-sm ${priceRange === i ? 'text-ink font-semibold' : 'text-ink-secondary'}`}>
                {r.label}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Minimum rating */}
      <div>
        <p className="text-ink text-xs font-black uppercase tracking-widest mb-3">Minimum Rating</p>
        <div className="flex gap-2">
          {[0, 4, 4.5, 4.8].map((r) => (
            <button
              key={r}
              onClick={() => setMinRating(r)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                minRating === r
                  ? 'bg-df-500 border-df-500 text-white'
                  : 'border-surface-border text-ink-secondary hover:border-df-400 hover:text-df-500'
              }`}
            >
              {r === 0 ? 'Any' : (
                <>
                  <Star className="w-3 h-3 fill-current" />{r}+
                </>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Toggles */}
      <div>
        <p className="text-ink text-xs font-black uppercase tracking-widest mb-3">Availability</p>
        <div className="flex flex-col gap-3">
          {([
            { label: 'On Sale', value: onlySale, set: setOnlySale },
            { label: 'New Arrivals', value: onlyNew, set: setOnlyNew },
          ] as const).map(({ label, value, set }) => (
            <label key={label} className="flex items-center justify-between cursor-pointer">
              <span className="text-ink-secondary text-sm">{label}</span>
              <div
                onClick={() => set(!value)}
                className={`relative w-9 h-5 rounded-full transition-colors cursor-pointer ${value ? 'bg-df-500' : 'bg-surface-border'}`}
              >
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform ${value ? 'translate-x-4' : 'translate-x-0.5'}`} />
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Reset */}
      {activeFilterCount > 0 && (
        <button
          onClick={() => { setPriceRange(0); setOnlySale(false); setOnlyNew(false); setMinRating(0); }}
          className="flex items-center gap-1.5 text-rose-500 hover:text-rose-600 text-xs font-semibold transition-colors"
        >
          <X className="w-3.5 h-3.5" />
          Clear {activeFilterCount} filter{activeFilterCount > 1 ? 's' : ''}
        </button>
      )}
    </div>
  );

  return (
    <section id="shop-grid" className="bg-surface-muted py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Results bar */}
        <div className="flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <p className="text-ink text-sm">
              <span className="font-black text-xl text-ink mr-1">{filtered.length}</span>
              {filtered.length === 1 ? 'product' : 'products'} found
            </p>
            {activeFilterCount > 0 && (
              <span className="bg-df-50 border border-df-200 text-df-600 text-xs font-bold px-2 py-0.5 rounded-full">
                {activeFilterCount} filter{activeFilterCount > 1 ? 's' : ''} active
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Mobile filter toggle */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden flex items-center gap-1.5 bg-white border border-surface-border text-ink-secondary text-sm font-semibold px-3 py-2 rounded-xl hover:border-df-400 hover:text-df-500 transition-all shadow-sm"
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filters
              {activeFilterCount > 0 && (
                <span className="bg-df-500 text-white text-[10px] font-black rounded-full w-4 h-4 flex items-center justify-center">
                  {activeFilterCount}
                </span>
              )}
            </button>

            {/* Sort */}
            <div className="relative">
              <button
                onClick={() => setSortOpen(!sortOpen)}
                className="flex items-center gap-2 bg-white border border-surface-border text-ink-secondary text-sm font-semibold px-3 py-2 rounded-xl hover:border-df-400 hover:text-df-500 transition-all shadow-sm"
              >
                {SORT_OPTIONS.find((o) => o.value === sort)?.label}
                <ChevronDown className={`w-4 h-4 transition-transform ${sortOpen ? 'rotate-180' : ''}`} />
              </button>
              {sortOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white border border-surface-border rounded-xl shadow-lg z-30 py-1 min-w-[180px]">
                  {SORT_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => { setSort(opt.value); setSortOpen(false); }}
                      className={`w-full text-left px-4 py-2.5 text-sm transition-colors ${
                        sort === opt.value
                          ? 'bg-df-50 text-df-600 font-bold'
                          : 'text-ink-secondary hover:bg-surface-muted hover:text-ink'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Layout toggle */}
            <div className="flex bg-white border border-surface-border rounded-xl overflow-hidden shadow-sm">
              <button
                onClick={() => setLayout('grid')}
                className={`p-2 transition-colors ${layout === 'grid' ? 'bg-df-500 text-white' : 'text-ink-muted hover:text-df-500'}`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setLayout('list')}
                className={`p-2 transition-colors ${layout === 'list' ? 'bg-df-500 text-white' : 'text-ink-muted hover:text-df-500'}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Layout */}
        <div className="flex gap-6">
          {/* Desktop sidebar */}
          <aside className="hidden lg:block w-56 flex-shrink-0">
            <div className="bg-white border border-surface-border rounded-2xl p-5 shadow-sm sticky top-32">
              <div className="flex items-center justify-between mb-5">
                <p className="text-ink font-black text-sm">Filters</p>
                {activeFilterCount > 0 && (
                  <span className="bg-df-500 text-white text-[10px] font-black rounded-full px-1.5 py-0.5">
                    {activeFilterCount}
                  </span>
                )}
              </div>
              <FilterPanel />
            </div>
          </aside>

          {/* Products */}
          <div className="flex-1 min-w-0">
            {filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center bg-white rounded-2xl border border-surface-border">
                <SlidersHorizontal className="w-10 h-10 text-ink-faint mb-3" />
                <p className="text-ink font-bold text-lg">No products match your filters</p>
                <p className="text-ink-muted text-sm mt-1">Try broadening your search</p>
                <button
                  onClick={() => { setPriceRange(0); setOnlySale(false); setOnlyNew(false); setMinRating(0); }}
                  className="mt-4 text-df-500 hover:text-df-700 text-sm font-bold underline underline-offset-2"
                >
                  Clear all filters
                </button>
              </div>
            ) : layout === 'grid' ? (
              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} onAddToCart={onAddToCart} inCart={cartIds.includes(p.id)} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {filtered.map((p) => (
                  <ProductListRow key={p.id} product={p} onAddToCart={onAddToCart} inCart={cartIds.includes(p.id)} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/40" onClick={() => setSidebarOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-white shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-surface-border">
              <p className="text-ink font-black">Filters</p>
              <button onClick={() => setSidebarOpen(false)}>
                <X className="w-5 h-5 text-ink-muted" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5">
              <FilterPanel />
            </div>
            <div className="p-5 border-t border-surface-border">
              <button
                onClick={() => setSidebarOpen(false)}
                className="w-full bg-df-500 hover:bg-df-600 text-white font-black py-3 rounded-xl transition-all"
              >
                Show {filtered.length} Results
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function ProductListRow({ product, onAddToCart, inCart }: { product: Product; onAddToCart: (p: Product) => void; inCart: boolean }) {
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <article className="bg-white border border-surface-border rounded-2xl overflow-hidden flex transition-all hover:border-df-300 hover:shadow-df-md shadow-sm group">
      <div className="relative w-40 sm:w-52 flex-shrink-0 overflow-hidden bg-surface-muted">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        {discount > 0 && (
          <div className="absolute top-0 left-0 bg-rose-500 text-white text-[10px] font-black px-2 py-1 rounded-br-xl">
            -{discount}%
          </div>
        )}
      </div>
      <div className="flex flex-col sm:flex-row flex-1 p-4 gap-4">
        <div className="flex-1 flex flex-col gap-2">
          <p className="text-df-500 text-[10px] font-bold uppercase tracking-widest">{product.category}</p>
          <h3 className="text-ink font-black text-base leading-tight group-hover:text-df-600 transition-colors">{product.name}</h3>
          <p className="text-ink-muted text-xs line-clamp-2">{product.subtitle}</p>
          <div className="flex items-center gap-2">
            {[1,2,3,4,5].map((i) => (
              <Star key={i} className={`w-3 h-3 ${i <= product.rating ? 'text-amber-400 fill-amber-400' : 'text-surface-border fill-surface-border'}`} />
            ))}
            <span className="text-ink-muted text-xs">({product.reviewCount.toLocaleString()})</span>
          </div>
          <div className="flex flex-wrap gap-1 mt-1">
            {product.includes.slice(0, 3).map((inc) => (
              <span key={inc} className="text-[10px] text-ink-muted bg-surface-muted border border-surface-border rounded px-1.5 py-0.5">{inc}</span>
            ))}
          </div>
        </div>
        <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-3 flex-shrink-0 sm:w-36">
          <div className="text-right">
            <p className="text-ink font-black text-xl">R{product.price.toLocaleString()}</p>
            {product.originalPrice && (
              <p className="text-ink-faint text-xs line-through">R{product.originalPrice.toLocaleString()}</p>
            )}
          </div>
          <button
            onClick={() => onAddToCart(product)}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-black text-sm transition-all ${
              inCart ? 'bg-emerald-500 hover:bg-emerald-600 text-white' : 'bg-df-500 hover:bg-df-600 text-white shadow-df-sm'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            {inCart ? 'Added' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </article>
  );
}
