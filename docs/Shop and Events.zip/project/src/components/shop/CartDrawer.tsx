import { X, ShoppingCart, Trash2, Plus, Minus, ArrowRight, Tag, Package } from 'lucide-react';
import type { CartItem } from '@/data/products';

interface Props {
  items: CartItem[];
  onClose: () => void;
  onUpdateQty: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
  onCheckout: () => void;
}

export default function CartDrawer({ items, onClose, onUpdateQty, onRemove, onCheckout }: Props) {
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const savings = items.reduce((sum, i) => {
    const orig = i.product.originalPrice ?? i.product.price;
    return sum + (orig - i.product.price) * i.quantity;
  }, 0);
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <div className="fixed inset-0 z-[60] flex">
      {/* Backdrop */}
      <div className="flex-1 bg-ink/40 backdrop-blur-sm" onClick={onClose} />

      {/* Drawer */}
      <div className="w-full max-w-[420px] bg-white flex flex-col h-full shadow-2xl">

        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-surface-border bg-white">
          <div className="flex items-center gap-2">
            <div className="bg-df-500 rounded-xl p-2">
              <ShoppingCart className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-ink font-black text-base leading-none">Your Cart</p>
              <p className="text-ink-muted text-xs mt-0.5">{itemCount} item{itemCount !== 1 ? 's' : ''}</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-surface-muted text-ink-muted hover:text-ink transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 p-10 text-center">
            <div className="w-16 h-16 bg-df-50 border border-df-200 rounded-2xl flex items-center justify-center">
              <Package className="w-7 h-7 text-df-400" />
            </div>
            <div>
              <p className="text-ink font-bold text-lg">Your cart is empty</p>
              <p className="text-ink-muted text-sm mt-1">Add some products to get started</p>
            </div>
            <button
              onClick={onClose}
              className="bg-df-500 hover:bg-df-600 text-white font-bold px-6 py-2.5 rounded-xl text-sm transition-all shadow-df-sm"
            >
              Browse Products
            </button>
          </div>
        ) : (
          <>
            {/* Items */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {items.map(({ product, quantity }) => {
                const discount = product.originalPrice
                  ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
                  : 0;
                return (
                  <div key={product.id} className="flex gap-3 bg-surface-muted border border-surface-border rounded-xl p-3">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-ink font-bold text-sm leading-tight line-clamp-2">{product.name}</p>
                        <button
                          onClick={() => onRemove(product.id)}
                          className="text-ink-faint hover:text-rose-500 transition-colors flex-shrink-0 p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-ink-muted text-[11px] mt-0.5">{product.category}</p>
                      <div className="flex items-center justify-between mt-2">
                        {/* Qty stepper */}
                        <div className="flex items-center gap-1 bg-white border border-surface-border rounded-lg overflow-hidden">
                          <button
                            onClick={() => onUpdateQty(product.id, Math.max(1, quantity - 1))}
                            className="p-1.5 hover:bg-surface-muted text-ink-secondary hover:text-ink transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-ink font-bold text-sm px-2 min-w-[1.5rem] text-center tabular-nums">
                            {quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQty(product.id, quantity + 1)}
                            className="p-1.5 hover:bg-surface-muted text-ink-secondary hover:text-ink transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        <div className="text-right">
                          <p className="text-ink font-black text-sm">
                            R{(product.price * quantity).toLocaleString()}
                          </p>
                          {discount > 0 && (
                            <p className="text-emerald-600 text-[10px] font-bold">-{discount}% off</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Promo code */}
            <div className="px-4 pb-4">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-faint" />
                  <input
                    type="text"
                    placeholder="Promo code"
                    className="w-full bg-surface-muted border border-surface-border rounded-xl pl-8 pr-3 py-2.5 text-sm text-ink placeholder-ink-faint focus:outline-none focus:border-df-400 focus:ring-2 focus:ring-df-100"
                  />
                </div>
                <button className="bg-surface-border hover:bg-df-500 hover:text-white text-ink-secondary font-bold text-sm px-4 py-2.5 rounded-xl transition-all">
                  Apply
                </button>
              </div>
            </div>

            {/* Summary */}
            <div className="p-4 border-t border-surface-border bg-surface-muted flex flex-col gap-3">
              <div className="flex flex-col gap-2">
                <div className="flex justify-between text-sm">
                  <span className="text-ink-secondary">Subtotal</span>
                  <span className="text-ink font-semibold">R{subtotal.toLocaleString()}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-emerald-600">You save</span>
                    <span className="text-emerald-600 font-bold">-R{savings.toLocaleString()}</span>
                  </div>
                )}
                <div className="border-t border-surface-border pt-2 flex justify-between">
                  <span className="text-ink font-black">Total</span>
                  <span className="text-ink font-black text-xl">R{subtotal.toLocaleString()}</span>
                </div>
              </div>

              <button
                onClick={onCheckout}
                className="flex items-center justify-center gap-2 w-full bg-df-500 hover:bg-df-600 text-white font-black py-4 rounded-xl transition-all shadow-df-md group"
              >
                Proceed to Checkout
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
              <p className="text-center text-ink-muted text-xs">Secure checkout — SSL encrypted</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
