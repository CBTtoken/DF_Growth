import { Star, ShoppingCart, Heart, Zap, CheckCircle2, Clock } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '@/data/products';

interface Props {
  product: Product;
  onAddToCart: (p: Product) => void;
  inCart: boolean;
}

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={`w-3 h-3 ${
            i <= Math.floor(rating)
              ? 'text-amber-400 fill-amber-400'
              : i - 0.5 <= rating
              ? 'text-amber-400 fill-amber-200'
              : 'text-surface-border fill-surface-border'
          }`}
        />
      ))}
    </div>
  );
}

const BADGE_STYLES: Record<string, string> = {
  'Best Seller': 'bg-df-500 text-white',
  'Hot Deal':    'bg-rose-500 text-white',
  'Top Rated':   'bg-amber-400 text-amber-900',
  'Popular':     'bg-emerald-500 text-white',
  New:           'bg-violet-500 text-white',
  '26% Off':     'bg-rose-500 text-white',
};

export default function ProductCard({ product, onAddToCart, inCart }: Props) {
  const [wishlisted, setWishlisted] = useState(false);
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;
  const outOfStock = product.stock === 0;

  return (
    <article className="group bg-white border border-surface-border rounded-2xl overflow-hidden flex flex-col transition-all duration-200 hover:border-df-300 hover:shadow-df-md hover:-translate-y-0.5 shadow-sm">

      {/* Image */}
      <div className="relative h-48 overflow-hidden bg-surface-muted flex-shrink-0">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent" />

        {/* Discount ribbon */}
        {discount > 0 && (
          <div className="absolute top-0 left-0">
            <div className="bg-rose-500 text-white text-[10px] font-black px-2.5 py-1 rounded-br-xl">
              -{discount}%
            </div>
          </div>
        )}

        {/* Badge */}
        {product.badge && (
          <div className={`absolute top-2 right-2 text-[10px] font-black uppercase tracking-wide px-2 py-0.5 rounded-full ${BADGE_STYLES[product.badge] ?? 'bg-df-500 text-white'}`}>
            {product.badge}
          </div>
        )}

        {/* Wishlist */}
        <button
          onClick={() => setWishlisted((v) => !v)}
          className="absolute bottom-2 right-2 w-7 h-7 bg-white rounded-full flex items-center justify-center shadow-md transition-all hover:scale-110"
        >
          <Heart
            className={`w-3.5 h-3.5 transition-colors ${wishlisted ? 'text-rose-500 fill-rose-500' : 'text-ink-muted'}`}
          />
        </button>

        {/* Out of stock overlay */}
        {outOfStock && (
          <div className="absolute inset-0 bg-white/70 flex items-center justify-center">
            <span className="bg-surface-border text-ink-secondary text-xs font-bold px-3 py-1.5 rounded-full">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col gap-3 p-4 flex-1">
        {/* Category */}
        <p className="text-df-500 text-[10px] font-bold uppercase tracking-widest">{product.category}</p>

        {/* Name */}
        <div>
          <h3 className="text-ink font-black text-sm leading-snug line-clamp-2 group-hover:text-df-600 transition-colors">
            {product.name}
          </h3>
          <p className="text-ink-muted text-xs mt-1 line-clamp-2 leading-snug">{product.subtitle}</p>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-2">
          <Stars rating={product.rating} />
          <span className="text-amber-600 text-xs font-bold">{product.rating}</span>
          <span className="text-ink-muted text-xs">({product.reviewCount.toLocaleString()})</span>
        </div>

        {/* Delivery */}
        <div className="flex items-center gap-1.5 text-xs">
          {product.deliveryLabel === 'Instant Download' ? (
            <>
              <Zap className="w-3.5 h-3.5 text-df-500 flex-shrink-0" />
              <span className="text-df-600 font-semibold">Instant Download</span>
            </>
          ) : (
            <>
              <Clock className="w-3.5 h-3.5 text-ink-faint flex-shrink-0" />
              <span className="text-ink-muted">{product.deliveryLabel}</span>
            </>
          )}
        </div>

        {/* Includes preview */}
        <div className="flex flex-col gap-1">
          {product.includes.slice(0, 2).map((item) => (
            <div key={item} className="flex items-start gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-emerald-500 mt-0.5 flex-shrink-0" />
              <span className="text-ink-muted text-[11px] leading-tight">{item}</span>
            </div>
          ))}
          {product.includes.length > 2 && (
            <p className="text-ink-faint text-[11px] ml-4.5">+{product.includes.length - 2} more</p>
          )}
        </div>

        {/* Price + CTA */}
        <div className="mt-auto pt-2 border-t border-surface-border flex items-center justify-between gap-3">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-ink font-black text-lg">R{product.price.toLocaleString()}</span>
              {product.originalPrice && (
                <span className="text-ink-faint text-xs line-through">R{product.originalPrice.toLocaleString()}</span>
              )}
            </div>
            {discount > 0 && (
              <p className="text-emerald-600 text-[11px] font-bold">
                Save R{(product.originalPrice! - product.price).toLocaleString()}
              </p>
            )}
          </div>

          <button
            disabled={outOfStock}
            onClick={() => !outOfStock && onAddToCart(product)}
            className={`
              flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-black text-xs transition-all flex-shrink-0
              ${outOfStock
                ? 'bg-surface-muted text-ink-faint cursor-not-allowed'
                : inCart
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm'
                : 'bg-df-500 hover:bg-df-600 text-white shadow-df-sm'
              }
            `}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            {inCart ? 'Added' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </article>
  );
}
