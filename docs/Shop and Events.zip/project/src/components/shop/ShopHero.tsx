import { ArrowRight, Zap, Shield, RefreshCw, Headphones, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';

const TRUST_ITEMS = [
  { icon: Zap, label: 'Instant Digital Delivery', sub: 'Downloads available immediately' },
  { icon: Shield, label: 'Secure Checkout', sub: 'SSL encrypted & safe' },
  { icon: RefreshCw, label: 'Revision Guarantee', sub: 'Not happy? We redo it' },
  { icon: Headphones, label: 'Local SA Support', sub: 'Mon–Fri, 8am–5pm SAST' },
];

function Countdown({ targetHours }: { targetHours: number }) {
  const [timeLeft, setTimeLeft] = useState(() => {
    const end = new Date();
    end.setHours(end.getHours() + targetHours, 0, 0, 0);
    return Math.max(0, Math.floor((end.getTime() - Date.now()) / 1000));
  });

  useEffect(() => {
    const t = setInterval(() => setTimeLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  const h = String(Math.floor(timeLeft / 3600)).padStart(2, '0');
  const m = String(Math.floor((timeLeft % 3600) / 60)).padStart(2, '0');
  const s = String(timeLeft % 60).padStart(2, '0');

  return (
    <div className="flex items-center gap-1">
      {[h, m, s].map((unit, i) => (
        <span key={i} className="flex items-center gap-1">
          <span className="bg-white/20 text-white font-black text-sm px-2 py-1 rounded-lg tabular-nums min-w-[2rem] text-center">
            {unit}
          </span>
          {i < 2 && <span className="text-white/70 font-bold text-sm">:</span>}
        </span>
      ))}
    </div>
  );
}

export default function ShopHero() {
  return (
    <div className="bg-white border-b border-surface-border">
      {/* Announcement bar */}
      <div className="bg-df-600 text-white text-center py-2 px-4">
        <p className="text-xs font-semibold tracking-wide">
          Free consultation with every marketing package purchase &mdash; this week only
          <a href="#" className="underline underline-offset-2 ml-2 font-bold hover:text-df-100 transition-colors">
            Shop Now &rarr;
          </a>
        </p>
      </div>

      {/* Main hero grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-5 gap-5">

          {/* Primary banner */}
          <div className="lg:col-span-3 relative rounded-2xl overflow-hidden min-h-[280px] flex items-end bg-gradient-to-br from-df-700 via-df-500 to-df-400 shadow-df-lg">
            {/* Dot pattern */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.07]"
              style={{ backgroundImage: 'radial-gradient(circle, white 1.5px, transparent 1.5px)', backgroundSize: '22px 22px' }} />
            {/* Image overlay */}
            <img
              src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Digital Marketing"
              className="absolute inset-0 w-full h-full object-cover object-top mix-blend-overlay opacity-30"
            />
            <div className="relative p-8 pb-8 flex flex-col gap-4 w-full">
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-amber-900 text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full">
                  Flash Sale
                </span>
                <span className="text-white/70 text-xs font-medium">Ends in</span>
                <Countdown targetHours={8} />
              </div>
              <div>
                <h2 className="text-white font-black text-3xl sm:text-4xl leading-tight tracking-tight mb-2">
                  Grow Your Business<br />
                  <span className="text-amber-300">Faster Online</span>
                </h2>
                <p className="text-df-100 text-sm leading-relaxed max-w-md">
                  Professional branding, digital marketing & design services built for South African businesses.
                  Up to <strong className="text-white">35% off</strong> this week.
                </p>
              </div>
              <a
                href="#shop-grid"
                className="inline-flex items-center gap-2 bg-white hover:bg-df-50 text-df-600 font-black text-sm px-6 py-3 rounded-xl transition-all w-fit shadow-lg group"
              >
                Shop All Deals
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </a>
            </div>
          </div>

          {/* Right column — two smaller promo cards */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div className="relative rounded-2xl overflow-hidden flex-1 min-h-[128px] bg-gradient-to-r from-amber-500 to-orange-500 flex items-end shadow-md">
              <img
                src="https://images.pexels.com/photos/326501/pexels-photo-326501.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Logo Design"
                className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-25"
              />
              <div className="relative p-5 w-full">
                <p className="text-amber-100 text-[10px] font-bold uppercase tracking-widest">Starting from</p>
                <p className="text-white font-black text-xl leading-none">R799 <span className="text-amber-200 font-semibold text-sm line-through">R1100</span></p>
                <p className="text-white font-bold text-sm mt-0.5">Logo &amp; Brand Design</p>
                <a href="#shop-grid" className="mt-2 inline-flex items-center gap-1 text-amber-100 hover:text-white text-xs font-semibold transition-colors">
                  Browse <ArrowRight className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="relative rounded-2xl overflow-hidden flex-1 min-h-[128px] bg-gradient-to-r from-emerald-600 to-df-500 flex items-end shadow-md">
              <img
                src="https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Social Media"
                className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-20"
              />
              <div className="relative p-5 w-full">
                <p className="text-emerald-100 text-[10px] font-bold uppercase tracking-widest">30-day pack</p>
                <p className="text-white font-black text-xl leading-none">R899 <span className="text-emerald-200 font-semibold text-sm line-through">R1400</span></p>
                <p className="text-white font-bold text-sm mt-0.5">Social Media Content</p>
                <a href="#shop-grid" className="mt-2 inline-flex items-center gap-1 text-emerald-100 hover:text-white text-xs font-semibold transition-colors">
                  Browse <ArrowRight className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Trust strip */}
      <div className="border-t border-surface-border bg-surface-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {TRUST_ITEMS.map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-df-50 border border-df-200 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4 h-4 text-df-500" />
                </div>
                <div>
                  <p className="text-ink text-xs font-bold leading-tight">{label}</p>
                  <p className="text-ink-muted text-[11px] leading-tight mt-0.5">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* "Deal of the day" ticker */}
      <div className="bg-df-500 py-2 px-4 overflow-hidden">
        <div className="flex items-center gap-2 max-w-7xl mx-auto">
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <Clock className="w-3.5 h-3.5 text-white" />
            <span className="text-white text-[10px] font-black uppercase tracking-widest">Deal of the Day</span>
            <span className="w-px h-3 bg-white/30 mx-1" />
          </div>
          <p className="text-df-100 text-xs font-medium truncate">
            Social Media Content Pack (30 Days) — now only <strong className="text-white">R899</strong> while stock lasts
          </p>
          <a href="#shop-grid" className="ml-auto flex-shrink-0 text-white text-xs font-bold hover:text-df-200 transition-colors flex items-center gap-1">
            Grab It <ArrowRight className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
}
