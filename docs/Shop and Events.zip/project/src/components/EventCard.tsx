import { MapPin, Clock, Users, Tag, Ticket, Star } from 'lucide-react';
import type { Event } from '@/data/events';

interface Props {
  event: Event;
  onBook: (event: Event) => void;
  isSelected: boolean;
}

const CATEGORY_COLORS: Record<string, string> = {
  Market:     'bg-emerald-50 text-emerald-700 border-emerald-200',
  Workshop:   'bg-df-50 text-df-600 border-df-200',
  Production: 'bg-violet-50 text-violet-700 border-violet-200',
  Networking: 'bg-amber-50 text-amber-700 border-amber-200',
  Festival:   'bg-rose-50 text-rose-700 border-rose-200',
};

function SeatsBar({ total, left }: { total: number; left: number }) {
  const pct = Math.round((left / total) * 100);
  const taken = total - left;
  const barColor =
    pct <= 10 ? 'bg-rose-500' : pct <= 30 ? 'bg-amber-500' : 'bg-emerald-500';
  const labelColor =
    pct <= 10 ? 'text-rose-600' : pct <= 30 ? 'text-amber-600' : 'text-emerald-600';

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Users className="w-3.5 h-3.5 text-ink-faint" />
          <span className="text-ink-muted text-xs font-medium">{taken} attending</span>
        </div>
        <span className={`text-xs font-bold ${labelColor}`}>
          {pct <= 10 ? 'Almost Full!' : `${left} seats left`}
        </span>
      </div>
      <div className="h-1.5 bg-surface-subtle rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${barColor}`}
          style={{ width: `${100 - pct}%` }}
        />
      </div>
    </div>
  );
}

export default function EventCard({ event, onBook, isSelected }: Props) {
  const isFree = event.price === 0;
  const ctaLabel = isFree ? 'Get Free Ticket' : `Book Slot — R${event.price}`;

  return (
    <article
      className={`
        group relative bg-white border rounded-2xl overflow-hidden flex flex-col transition-all duration-200
        hover:border-df-400 hover:shadow-df-md hover:-translate-y-0.5
        ${isSelected ? 'border-df-500 shadow-df-md ring-2 ring-df-200' : 'border-surface-border shadow-sm'}
      `}
    >
      {/* Image */}
      <div className="relative w-full h-48 overflow-hidden bg-surface-muted flex-shrink-0">
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

        {/* Date sticker */}
        <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-sm border border-surface-border rounded-xl overflow-hidden text-center min-w-[52px] shadow-md">
          <div className="bg-df-500 px-2 pt-1 pb-0.5">
            <p className="text-white text-[9px] font-black tracking-widest uppercase leading-none">
              {event.dateLabel.split(' ')[0]}
            </p>
          </div>
          <div className="px-2 py-1">
            <p className="text-ink font-black text-xl leading-none">
              {event.dateLabel.split(' ')[1]}
            </p>
          </div>
        </div>

        {/* Featured badge */}
        {event.isFeatured && (
          <div className="absolute top-3 right-3 flex items-center gap-1 bg-amber-400 rounded-full px-2 py-0.5 shadow">
            <Star className="w-3 h-3 text-white fill-white" />
            <span className="text-white text-[10px] font-bold uppercase tracking-wide">Featured</span>
          </div>
        )}

        {/* Free badge */}
        {isFree && (
          <div className="absolute bottom-3 right-3 bg-emerald-500 rounded-full px-2.5 py-0.5 shadow">
            <span className="text-white text-[10px] font-black uppercase tracking-wide">Free Entry</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col gap-3 p-4 flex-1">
        {/* Category + day */}
        <div className="flex items-center justify-between gap-2">
          <span
            className={`text-[10px] font-bold uppercase tracking-widest border rounded-full px-2.5 py-0.5 ${
              CATEGORY_COLORS[event.category] ?? 'bg-surface-muted text-ink-muted border-surface-border'
            }`}
          >
            {event.category}
          </span>
          <span className="text-ink-muted text-xs font-medium">{event.dayName}</span>
        </div>

        {/* Title */}
        <div>
          <h3 className="text-ink font-black text-base leading-tight line-clamp-2 group-hover:text-df-600 transition-colors">
            {event.title}
          </h3>
          <p className="text-ink-muted text-xs mt-1 leading-snug line-clamp-2">{event.subtitle}</p>
        </div>

        {/* Meta */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-1.5 text-ink-secondary text-xs">
            <Clock className="w-3.5 h-3.5 flex-shrink-0 text-ink-faint" />
            <span>{event.timeStart} – {event.timeEnd}</span>
          </div>
          <div className="flex items-center gap-1.5 text-ink-secondary text-xs">
            <MapPin className="w-3.5 h-3.5 flex-shrink-0 text-ink-faint" />
            <span className="truncate">{event.venue}, {event.city}</span>
          </div>
          <div className="flex items-center gap-1.5 text-ink-secondary text-xs">
            <Tag className="w-3.5 h-3.5 flex-shrink-0 text-ink-faint" />
            <span>{event.hostName}</span>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1">
          {event.tags.map((tag) => (
            <span key={tag} className="text-[10px] text-ink-muted bg-surface-muted border border-surface-border rounded px-1.5 py-0.5">
              #{tag}
            </span>
          ))}
        </div>

        {/* Seats bar */}
        <SeatsBar total={event.totalSeats} left={event.seatsLeft} />

        {/* CTA */}
        <button
          onClick={() => onBook(event)}
          className={`
            mt-auto flex items-center justify-center gap-2 w-full py-3 rounded-xl font-black text-sm transition-all
            ${isSelected
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm'
              : isFree
              ? 'bg-df-500 hover:bg-df-600 active:bg-df-700 text-white shadow-df-sm'
              : 'bg-df-500 hover:bg-df-600 active:bg-df-700 text-white shadow-df-sm'
            }
          `}
        >
          <Ticket className="w-4 h-4" />
          {isSelected ? 'Ticket Added' : ctaLabel}
        </button>
      </div>
    </article>
  );
}
