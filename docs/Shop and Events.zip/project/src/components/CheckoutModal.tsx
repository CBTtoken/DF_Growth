import { X, Ticket, MapPin, Clock, CheckCircle2, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import type { Event } from '@/data/events';

interface Props {
  selected: Event[];
  onClose: () => void;
  onConfirm: () => void;
}

export default function CheckoutModal({ selected, onClose, onConfirm }: Props) {
  const [confirmed, setConfirmed] = useState(false);
  const total = selected.reduce((sum, e) => sum + e.price, 0);

  function handleConfirm() {
    setConfirmed(true);
    setTimeout(onConfirm, 2200);
  }

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-ink/40 backdrop-blur-sm p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="bg-white border border-surface-border rounded-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">

        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-surface-border">
          <div className="flex items-center gap-2">
            <div className="bg-df-500 rounded-lg p-1.5">
              <Ticket className="w-4 h-4 text-white" />
            </div>
            <h2 className="text-ink font-black text-lg">Your Tickets</h2>
          </div>
          <button onClick={onClose} className="text-ink-muted hover:text-ink transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmed ? (
          <div className="flex flex-col items-center justify-center gap-4 p-10 text-center">
            <div className="w-16 h-16 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-500" />
            </div>
            <div>
              <p className="text-ink font-black text-xl">Tickets Reserved!</p>
              <p className="text-ink-secondary text-sm mt-1">
                Check your email for confirmation and QR codes.
              </p>
            </div>
          </div>
        ) : (
          <>
            {/* Event list */}
            <div className="overflow-y-auto flex-1 p-5 flex flex-col gap-3">
              {selected.map((event) => (
                <div key={event.id} className="flex gap-3 bg-surface-muted border border-surface-border rounded-xl p-3">
                  <img
                    src={event.imageUrl}
                    alt={event.title}
                    className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-ink font-bold text-sm leading-tight truncate">{event.title}</p>
                    <div className="flex items-center gap-1 mt-1 text-ink-muted text-xs">
                      <Clock className="w-3 h-3 text-ink-faint" />
                      <span>{event.dateLabel} · {event.timeStart}</span>
                    </div>
                    <div className="flex items-center gap-1 text-ink-muted text-xs">
                      <MapPin className="w-3 h-3 text-ink-faint" />
                      <span className="truncate">{event.venue}, {event.city}</span>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-ink font-black text-base">
                      {event.price === 0 ? 'Free' : `R${event.price}`}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Total + CTA */}
            <div className="p-5 border-t border-surface-border flex flex-col gap-3 bg-surface-muted">
              <div className="flex items-center justify-between">
                <span className="text-ink-secondary text-sm">Total ({selected.length} ticket{selected.length > 1 ? 's' : ''})</span>
                <span className="text-ink font-black text-2xl">
                  {total === 0 ? 'Free' : `R${total}`}
                </span>
              </div>
              <button
                onClick={handleConfirm}
                className="flex items-center justify-center gap-2 w-full bg-df-500 hover:bg-df-600 text-white font-black py-4 rounded-xl transition-all shadow-df-md group"
              >
                {total === 0 ? 'Claim My Free Tickets' : 'Confirm & Pay'}
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
              <p className="text-center text-ink-muted text-xs">
                Tickets delivered instantly to your email
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
