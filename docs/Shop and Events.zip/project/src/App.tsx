import { useState, useCallback } from 'react';
import Navbar from '@/components/Navbar';
import HeroRow from '@/components/HeroRow';
import EventsGrid from '@/components/EventsGrid';
import StickyTicketFooter from '@/components/StickyTicketFooter';
import CheckoutModal from '@/components/CheckoutModal';
import ShopPage from '@/pages/ShopPage';
import { events, type Event } from '@/data/events';

type Page = 'events' | 'shop';

export default function App() {
  const [page, setPage] = useState<Page>('events');

  // Events state
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // Shop state
  const [cartCount, setCartCount] = useState(0);
  const [cartOpen, setCartOpen] = useState(false);

  const selectedEvents = events.filter((e) => selectedIds.includes(e.id));

  const handleBook = useCallback((event: Event) => {
    setSelectedIds((prev) =>
      prev.includes(event.id)
        ? prev.filter((id) => id !== event.id)
        : [...prev, event.id]
    );
  }, []);

  const handleRemoveTicket = useCallback((id: string) => {
    setSelectedIds((prev) => prev.filter((i) => i !== id));
  }, []);

  const handleNavigate = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-surface-muted">
      <Navbar
        page={page}
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setCartOpen(true)}
      />

      {page === 'events' ? (
        <>
          <HeroRow />
          <EventsGrid selectedIds={selectedIds} onBook={handleBook} />
          {selectedIds.length > 0 && <div className="h-20" />}
          <StickyTicketFooter
            selected={selectedEvents}
            onRemove={handleRemoveTicket}
            onCheckout={() => setCheckoutOpen(true)}
          />
          {checkoutOpen && (
            <CheckoutModal
              selected={selectedEvents}
              onClose={() => setCheckoutOpen(false)}
              onConfirm={() => {
                setSelectedIds([]);
                setCheckoutOpen(false);
              }}
            />
          )}
        </>
      ) : (
        <ShopPage
          cartItemCount={cartCount}
          onCartCountChange={setCartCount}
          cartOpen={cartOpen}
          onOpenCart={() => setCartOpen(true)}
          onCloseCart={() => setCartOpen(false)}
        />
      )}
    </div>
  );
}
