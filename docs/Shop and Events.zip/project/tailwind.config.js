/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      screens: {
        xs: '400px',
      },
      fontFamily: {
        sans: [
          'Inter',
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'sans-serif',
        ],
      },
      colors: {
        df: {
          50:  '#e8f6fc',
          100: '#c6eaf7',
          200: '#94d4ef',
          300: '#56bae4',
          400: '#2aa4d8',
          500: '#1e9dc8',  // primary brand blue from logo
          600: '#1680a8',
          700: '#126590',
          800: '#0e4e70',
          900: '#0a3a52',
        },
        surface: {
          DEFAULT: '#ffffff',
          muted:   '#f4f8fb',
          subtle:  '#e9f3f8',
          border:  '#d1e8f2',
        },
        ink: {
          DEFAULT: '#0f2336',
          secondary: '#3d5a70',
          muted:   '#7a9aaa',
          faint:   '#b0ccd8',
        },
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      boxShadow: {
        'df-sm':  '0 2px 8px 0 rgba(30,157,200,0.12)',
        'df-md':  '0 4px 20px 0 rgba(30,157,200,0.18)',
        'df-lg':  '0 8px 32px 0 rgba(30,157,200,0.22)',
      },
    },
  },
  plugins: [],
};
